<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Nobanno - Orders</title>

    <link rel="stylesheet" href="../css/AdminOrders.css">

</head>


<body>


    <!-- ================= SIDEBAR ================= -->

    <aside class="sidebar">


        <div class="logo-section">

            <div class="logo-icon">
                🌾
            </div>

            <div class="logo-text">

                <h2>নবান্ন</h2>

                <p>Admin Panel</p>

            </div>

        </div>



        <!-- NAVIGATION -->

        <nav class="sidebar-nav">


            <a href="AdminDashboard.php" class="nav-item">

                <span class="nav-icon">📊</span>

                <span>Dashboard</span>

            </a>


            <a href="AdminUsers.php" class="nav-item">

                <span class="nav-icon">👥</span>

                <span>Users</span>

            </a>


            <a href="AdminFarmers.php" class="nav-item">

                <span class="nav-icon">🌾</span>

                <span>Farmers</span>

            </a>


            <a href="AdminDeliveryMen.php" class="nav-item">

                <span class="nav-icon">🚚</span>

                <span>Delivery Men</span>

            </a>


            <a href="AdminCustomers.php" class="nav-item">

                <span class="nav-icon">🛒</span>

                <span>Customers</span>

            </a>


            <a href="AdminCrops.php" class="nav-item">

                <span class="nav-icon">🥬</span>

                <span>Crops</span>

            </a>


            <a href="AdminOrders.php" class="nav-item active">

                <span class="nav-icon">📦</span>

                <span>Orders</span>

            </a>


        </nav>



        <!-- LOGOUT -->

        <div class="sidebar-bottom">

            <a href="#" class="logout-btn">

                <span class="nav-icon">🚪</span>

                <span>Logout</span>

            </a>

        </div>


    </aside>



    <!-- ================= MAIN CONTENT ================= -->

    <main class="main-content">



        <!-- ================= TOP BAR ================= -->

        <header class="topbar">


            <div class="page-title">

                <h1>Orders</h1>

                <p>Manage customer orders and deliveries</p>

            </div>



            <div class="admin-profile">


                <div class="profile-icon">
                    A
                </div>


                <div class="profile-info">

                    <strong>Admin</strong>

                    <span>Administrator</span>

                </div>


            </div>


        </header>



        <!-- ================= PAGE CONTENT ================= -->

        <section class="page-content">



            <!-- PAGE HEADER -->

            <div class="content-header">

                <div>

                    <h2>Order Management</h2>

                    <p>
                        Monitor orders, payments and delivery
                        status across Nobanno.
                    </p>

                </div>

            </div>



            <!-- ================= STATISTICS ================= -->

            <div class="order-stats">


                <!-- TOTAL ORDERS -->

                <div class="stat-card">

                    <div class="stat-icon total-icon">
                        📦
                    </div>

                    <div class="stat-info">

                        <p>Total Orders</p>

                        <h3>356</h3>

                    </div>

                </div>



                <!-- PENDING -->

                <div class="stat-card">

                    <div class="stat-icon pending-icon">
                        ⏳
                    </div>

                    <div class="stat-info">

                        <p>Pending</p>

                        <h3>42</h3>

                    </div>

                </div>



                <!-- PROCESSING -->

                <div class="stat-card">

                    <div class="stat-icon processing-icon">
                        ⚙
                    </div>

                    <div class="stat-info">

                        <p>Processing</p>

                        <h3>68</h3>

                    </div>

                </div>



                <!-- DELIVERING -->

                <div class="stat-card">

                    <div class="stat-icon delivery-icon">
                        🚚
                    </div>

                    <div class="stat-info">

                        <p>Out for Delivery</p>

                        <h3>31</h3>

                    </div>

                </div>



                <!-- COMPLETED -->

                <div class="stat-card">

                    <div class="stat-icon completed-icon">
                        ✓
                    </div>

                    <div class="stat-info">

                        <p>Completed</p>

                        <h3>215</h3>

                    </div>

                </div>


            </div>



            <!-- ================= FILTER ================= -->

            <div class="filter-section">


                <!-- SEARCH -->

                <div class="search-box">

                    <span>🔍</span>

                    <input
                        type="text"
                        placeholder="Search order ID, customer or farmer..."
                    >

                </div>



                <!-- ORDER STATUS -->

                <select class="status-filter">

                    <option value="all">
                        All Status
                    </option>

                    <option value="pending">
                        Pending
                    </option>

                    <option value="processing">
                        Processing
                    </option>

                    <option value="delivery">
                        Out for Delivery
                    </option>

                    <option value="completed">
                        Completed
                    </option>

                    <option value="cancelled">
                        Cancelled
                    </option>

                </select>



                <!-- PAYMENT -->

                <select class="payment-filter">

                    <option value="all">
                        All Payments
                    </option>

                    <option value="paid">
                        Paid
                    </option>

                    <option value="pending">
                        Payment Pending
                    </option>

                    <option value="cod">
                        Cash on Delivery
                    </option>

                </select>



                <!-- DATE -->

                <select class="date-filter">

                    <option value="all">
                        All Dates
                    </option>

                    <option value="today">
                        Today
                    </option>

                    <option value="week">
                        This Week
                    </option>

                    <option value="month">
                        This Month
                    </option>

                </select>


            </div>



            <!-- ================= ORDERS TABLE ================= -->

            <div class="orders-card">


                <div class="table-header">

                    <div>

                        <h3>Order List</h3>

                        <p>
                            356 total orders
                        </p>

                    </div>

                </div>



                <div class="table-container">


                    <table>


                        <thead>

                            <tr>

                                <th>Order</th>

                                <th>Customer</th>

                                <th>Crop</th>

                                <th>Farmer</th>

                                <th>Amount</th>

                                <th>Payment</th>

                                <th>Delivery</th>

                                <th>Status</th>

                                <th>Action</th>

                            </tr>

                        </thead>



                        <tbody>


                            <!-- ORDER 1 -->

                            <tr>


                                <td>

                                    <div class="order-id">

                                        <strong>
                                            #ORD001
                                        </strong>

                                        <span>
                                            25 Aug 2026
                                        </span>

                                    </div>

                                </td>


                                <td>

                                    <div class="customer-info">

                                        <div class="avatar">
                                            R
                                        </div>

                                        <span>
                                            Rakib Hasan
                                        </span>

                                    </div>

                                </td>


                                <td>

                                    <div class="crop-info">

                                        <span class="crop-icon">
                                            🍅
                                        </span>

                                        <div>

                                            <strong>
                                                Tomato
                                            </strong>

                                            <span>
                                                10 Kg
                                            </span>

                                        </div>

                                    </div>

                                </td>


                                <td>
                                    Rahim Ahmed
                                </td>


                                <td>
                                    <strong>৳600</strong>
                                </td>


                                <td>

                                    <span class="payment paid">
                                        Paid
                                    </span>

                                </td>


                                <td>
                                    Karim
                                </td>


                                <td>

                                    <span class="order-status delivery">
                                        Out for Delivery
                                    </span>

                                </td>


                                <td>

                                    <button class="action-btn view">
                                        View
                                    </button>

                                </td>


                            </tr>



                            <!-- ORDER 2 -->

                            <tr>


                                <td>

                                    <div class="order-id">

                                        <strong>
                                            #ORD002
                                        </strong>

                                        <span>
                                            25 Aug 2026
                                        </span>

                                    </div>

                                </td>


                                <td>

                                    <div class="customer-info">

                                        <div class="avatar">
                                            T
                                        </div>

                                        <span>
                                            Tanvir Ahmed
                                        </span>

                                    </div>

                                </td>


                                <td>

                                    <div class="crop-info">

                                        <span class="crop-icon">
                                            🥔
                                        </span>

                                        <div>

                                            <strong>
                                                Potato
                                            </strong>

                                            <span>
                                                20 Kg
                                            </span>

                                        </div>

                                    </div>

                                </td>


                                <td>
                                    Hasan Ali
                                </td>


                                <td>
                                    <strong>৳900</strong>
                                </td>


                                <td>

                                    <span class="payment cod">
                                        COD
                                    </span>

                                </td>


                                <td>
                                    Rahim
                                </td>


                                <td>

                                    <span class="order-status processing">
                                        Processing
                                    </span>

                                </td>


                                <td>

                                    <button class="action-btn view">
                                        View
                                    </button>

                                </td>


                            </tr>



                            <!-- ORDER 3 -->

                            <tr>


                                <td>

                                    <div class="order-id">

                                        <strong>
                                            #ORD003
                                        </strong>

                                        <span>
                                            24 Aug 2026
                                        </span>

                                    </div>

                                </td>


                                <td>

                                    <div class="customer-info">

                                        <div class="avatar">
                                            N
                                        </div>

                                        <span>
                                            Nadia Rahman
                                        </span>

                                    </div>

                                </td>


                                <td>

                                    <div class="crop-info">

                                        <span class="crop-icon">
                                            🥭
                                        </span>

                                        <div>

                                            <strong>
                                                Mango
                                            </strong>

                                            <span>
                                                15 Kg
                                            </span>

                                        </div>

                                    </div>

                                </td>


                                <td>
                                    Selim Mia
                                </td>


                                <td>
                                    <strong>৳1,800</strong>
                                </td>


                                <td>

                                    <span class="payment paid">
                                        Paid
                                    </span>

                                </td>


                                <td>
                                    Hasan
                                </td>


                                <td>

                                    <span class="order-status completed">
                                        Completed
                                    </span>

                                </td>


                                <td>

                                    <button class="action-btn view">
                                        View
                                    </button>

                                </td>


                            </tr>



                            <!-- ORDER 4 -->

                            <tr>


                                <td>

                                    <div class="order-id">

                                        <strong>
                                            #ORD004
                                        </strong>

                                        <span>
                                            24 Aug 2026
                                        </span>

                                    </div>

                                </td>


                                <td>

                                    <div class="customer-info">

                                        <div class="avatar">
                                            S
                                        </div>

                                        <span>
                                            Sumaiya Akter
                                        </span>

                                    </div>

                                </td>


                                <td>

                                    <div class="crop-info">

                                        <span class="crop-icon">
                                            🌶️
                                        </span>

                                        <div>

                                            <strong>
                                                Chili
                                            </strong>

                                            <span>
                                                5 Kg
                                            </span>

                                        </div>

                                    </div>

                                </td>


                                <td>
                                    Abdul Karim
                                </td>


                                <td>
                                    <strong>৳900</strong>
                                </td>


                                <td>

                                    <span class="payment pending">
                                        Pending
                                    </span>

                                </td>


                                <td>
                                    Not Assigned
                                </td>


                                <td>

                                    <span class="order-status pending">
                                        Pending
                                    </span>

                                </td>


                                <td>

                                    <button class="action-btn view">
                                        View
                                    </button>

                                </td>


                            </tr>



                            <!-- ORDER 5 -->

                            <tr>


                                <td>

                                    <div class="order-id">

                                        <strong>
                                            #ORD005
                                        </strong>

                                        <span>
                                            23 Aug 2026
                                        </span>

                                    </div>

                                </td>


                                <td>

                                    <div class="customer-info">

                                        <div class="avatar">
                                            A
                                        </div>

                                        <span>
                                            Arif Hossain
                                        </span>

                                    </div>

                                </td>


                                <td>

                                    <div class="crop-info">

                                        <span class="crop-icon">
                                            🌾
                                        </span>

                                        <div>

                                            <strong>
                                                Rice
                                            </strong>

                                            <span>
                                                25 Kg
                                            </span>

                                        </div>

                                    </div>

                                </td>


                                <td>
                                    Mahmud Hasan
                                </td>


                                <td>
                                    <strong>৳1,750</strong>
                                </td>


                                <td>

                                    <span class="payment paid">
                                        Paid
                                    </span>

                                </td>


                                <td>
                                    Karim
                                </td>


                                <td>

                                    <span class="order-status completed">
                                        Completed
                                    </span>

                                </td>


                                <td>

                                    <button class="action-btn view">
                                        View
                                    </button>

                                </td>


                            </tr>


                        </tbody>


                    </table>


                </div>



                <!-- PAGINATION -->

                <div class="pagination">


                    <button class="page-btn">
                        ‹
                    </button>


                    <button class="page-btn current">
                        1
                    </button>


                    <button class="page-btn">
                        2
                    </button>


                    <button class="page-btn">
                        3
                    </button>


                    <span>...</span>


                    <button class="page-btn">
                        36
                    </button>


                    <button class="page-btn">
                        ›
                    </button>


                </div>


            </div>


        </section>


    </main>


</body>

</html>