<?php

session_start();

require_once __DIR__ . '/../db.php';

$errorMessage = "";


/* =========================================================
   IF ALREADY LOGGED IN
========================================================= */

if (isset($_SESSION['user_id'], $_SESSION['role'])) {

    $currentRole = strtolower(
        trim($_SESSION['role'])
    );


    switch ($currentRole) {

        case 'admin':

            header(
                "Location: AdminDashboard.php"
            );

            exit();


        case 'farmer':

            header(
                "Location: FarmerDashboard/farmer_dashboard.php"
            );

            exit();


    case 'delivery_man':

    header(
        "Location: DeliveryManDashboard/delivery_dashboard.php"
    );

    exit();


case 'delivery':

    header(
        "Location: DeliveryManDashboard/delivery_dashboard.php"
    );

    exit();


        case 'customer':

            header(
                "Location: CustomerDashboard/customer_dashboard.php"
            );

            exit();


        default:

            session_unset();
            session_destroy();

            session_start();

            break;
    }
}


/* =========================================================
   LOGIN
========================================================= */

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $email = trim(
        $_POST['email'] ?? ""
    );

    $password =
        $_POST['password'] ?? "";


    /* =====================================================
       VALIDATION
    ===================================================== */

    if (
        $email === "" ||
        $password === ""
    ) {

        $errorMessage =
            "Please enter both email and password.";

    } elseif (
        !filter_var(
            $email,
            FILTER_VALIDATE_EMAIL
        )
    ) {

        $errorMessage =
            "Please enter a valid email address.";

    } else {


        /* =================================================
           FIND USER
        ================================================= */

        $query = "
            SELECT
                user_id,
                first_name,
                last_name,
                email,
                password,
                role,
                phone
            FROM users
            WHERE email = ?
            LIMIT 1
        ";


        $stmt = mysqli_prepare(
            $conn,
            $query
        );


        if (!$stmt) {

            $errorMessage =
                "Database error. Please try again.";

        } else {


            mysqli_stmt_bind_param(
                $stmt,
                "s",
                $email
            );


            mysqli_stmt_execute(
                $stmt
            );


            $result =
                mysqli_stmt_get_result(
                    $stmt
                );


            /* =============================================
               USER FOUND
            ============================================= */

            if (
                $result &&
                mysqli_num_rows($result) === 1
            ) {

                $user =
                    mysqli_fetch_assoc(
                        $result
                    );


                /* =========================================
                   PASSWORD CHECK
                ========================================= */

                if (
                    password_verify(
                        $password,
                        $user['password']
                    )
                ) {


                    /* =====================================
                       CREATE NEW SESSION
                    ===================================== */

                    session_regenerate_id(true);


                    $_SESSION['user_id'] =
                        $user['user_id'];


                    $_SESSION['first_name'] =
                        $user['first_name'];


                    $_SESSION['last_name'] =
                        $user['last_name'];


                    $_SESSION['email'] =
                        $user['email'];


                    $_SESSION['role'] =
                        strtolower(
                            trim(
                                $user['role']
                            )
                        );


                    $_SESSION['phone'] =
                        $user['phone'] ?? "";


                    /* =====================================
                       ROLE BASED REDIRECTION
                    ===================================== */

                    switch (
                        $_SESSION['role']
                    ) {


                        /* ================================
                           ADMIN
                        ================================= */

                        case 'admin':

                            header(
                                "Location: AdminDashboard.php"
                            );

                            exit();


                        /* ================================
                           FARMER
                        ================================= */

                        case 'farmer':

                            header(
                                "Location: FarmerDashboard/farmer_dashboard.php"
                            );

                            exit();


                        /* ================================
                           DELIVERY
                        ================================= */

case 'delivery_man':
    header("Location: DeliveryManDashboard/delivery_dashboard.php");
    exit();

case 'delivery':
    header("Location: DeliveryManDashboard/delivery_dashboard.php");
    exit();

                        /* ================================
                           CUSTOMER
                        ================================= */

                        case 'customer':

                            header(
                                "Location: CustomerDashboard.php"
                            );

                            exit();


                        /* ================================
                           INVALID ROLE
                        ================================= */

                        default:

                            session_unset();

                            session_destroy();

                            session_start();

                            $errorMessage =
                                "Your account role is not configured correctly.";

                            break;
                    }


                } else {

                    $errorMessage =
                        "Incorrect email or password.";
                }


            } else {

                $errorMessage =
                    "Incorrect email or password.";
            }


            mysqli_stmt_close(
                $stmt
            );
        }
    }
}

?>


<!DOCTYPE html>

<html lang="en">


<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Agro-Farm | Login
    </title>

    <link
        rel="stylesheet"
        href="../css/login.css"
    >

</head>


<body>


<div class="login-page">


    <!-- ==================================================
         LEFT SIDE
    =================================================== -->

    <div class="login-left">


        <div class="brand">


            <div class="brand-icon">
                🌾
            </div>


            <div class="brand-text">

                <h1>
                    নবান্ন
                </h1>

                <p>
                    Fresh From Farmers
                </p>

            </div>


        </div>


        <div class="welcome-content">


            <span class="welcome-label">
                WELCOME BACK
            </span>


            <h2>
                Welcome Back
            </h2>


            <p>
                Login to your Agro-Farm account
                and continue managing your
                agricultural marketplace.
            </p>


            <div class="feature-list">


                <div class="feature">


                    <span class="feature-icon">
                        ✓
                    </span>


                    <p>
                        Connect farmers with customers
                    </p>


                </div>


                <div class="feature">


                    <span class="feature-icon">
                        ✓
                    </span>


                    <p>
                        Manage fresh agricultural products
                    </p>


                </div>


                <div class="feature">


                    <span class="feature-icon">
                        ✓
                    </span>


                    <p>
                        Track orders and deliveries
                    </p>


                </div>


            </div>


        </div>


    </div>



    <!-- ==================================================
         RIGHT SIDE
    =================================================== -->

    <div class="login-right">


        <div class="login-card">


            <!-- HEADER -->

            <div class="login-header">


                <div class="mobile-logo">
                    🌾
                </div>


                <span class="form-label">
                    ACCOUNT LOGIN
                </span>


                <h2>
                    Login
                </h2>


                <p>
                    Enter your account details
                </p>


            </div>



            <!-- ERROR -->

            <?php if (!empty($errorMessage)): ?>

                <div class="error-message">

                    <span>
                        !
                    </span>

                    <?php
                    echo htmlspecialchars(
                        $errorMessage
                    );
                    ?>

                </div>

            <?php endif; ?>



            <!-- LOGIN FORM -->

            <form
                method="POST"
                action=""
            >


                <!-- EMAIL -->

                <div class="form-group">


                    <label
                        for="email"
                    >
                        Email Address
                    </label>


                    <input
                        type="email"
                        id="email"
                        name="email"
                        placeholder="Enter your email"
                        value="<?php

                        echo htmlspecialchars(
                            $_POST['email']
                            ?? ""
                        );

                        ?>"
                        required
                        autocomplete="email"
                    >


                </div>



                <!-- PASSWORD -->

                <div class="form-group">


                    <div class="password-label">


                        <label
                            for="password"
                        >
                            Password
                        </label>


                        <a
                            href="#"
                            class="forgot-link"
                        >
                            Forgot password?
                        </a>


                    </div>


                    <input
                        type="password"
                        id="password"
                        name="password"
                        placeholder="Enter your password"
                        required
                        autocomplete="current-password"
                    >


                </div>



                <!-- REMEMBER -->

                <div class="remember-row">


                    <label class="remember">


                        <input
                            type="checkbox"
                            name="remember"
                        >


                        <span>
                            Remember me
                        </span>


                    </label>


                </div>



                <!-- LOGIN BUTTON -->

                <button
                    type="submit"
                    class="login-btn"
                >

                    <span>
                        Login
                    </span>

                    <span class="button-arrow">
                        →
                    </span>

                </button>


            </form>



            <!-- REGISTER -->

            <div class="register-section">


                <span>
                    Don't have an account?
                </span>


                <a href="register.php">
                    Create Account
                </a>


            </div>


            <!-- FARMER REGISTER -->

            <div class="farmer-register">


                <span>
                    Want to sell your crops?
                </span>


                <a href="farmer_register.php">
                    Register as Farmer
                </a>


            </div>



            <!-- FOOTER -->

            <div class="login-footer">


                <p>

                    © <?php echo date("Y"); ?>

                    Agro-Farm.
                    All rights reserved.

                </p>


            </div>


        </div>


    </div>


</div>


</body>

</html>