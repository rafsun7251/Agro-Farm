<?php

session_start();

require_once __DIR__ . '/../db.php';


/*
|--------------------------------------------------------------------------
| GET PRODUCT ID
|--------------------------------------------------------------------------
*/

$cropId = isset($_GET['id']) ? (int) $_GET['id'] : 0;


/*
|--------------------------------------------------------------------------
| CROP DATA
|--------------------------------------------------------------------------
| This is the same basic crop information used for the
| product details page.
|--------------------------------------------------------------------------
*/

$crops = [

    1 => [
        'id' => 1,
        'name' => 'Potato',
        'category' => 'Vegetables',
        'description' => 'Fresh locally grown potatoes with excellent quality. Perfect for everyday cooking and household use.',
        'price' => 60,
        'unit' => 'kg',
        'stock' => 120,
        'farmer' => 'Local Farmer',
        'icon' => '🥔'
    ],

    2 => [
        'id' => 2,
        'name' => 'Tomato',
        'category' => 'Vegetables',
        'description' => 'Fresh red tomatoes directly from local farms. Carefully grown and suitable for everyday cooking.',
        'price' => 80,
        'unit' => 'kg',
        'stock' => 85,
        'farmer' => 'Local Farmer',
        'icon' => '🍅'
    ],

    3 => [
        'id' => 3,
        'name' => 'Onion',
        'category' => 'Vegetables',
        'description' => 'Fresh local onions with excellent quality. A reliable choice for your daily cooking needs.',
        'price' => 70,
        'unit' => 'kg',
        'stock' => 150,
        'farmer' => 'Local Farmer',
        'icon' => '🧅'
    ],

    4 => [
        'id' => 4,
        'name' => 'Rice',
        'category' => 'Grains',
        'description' => 'Premium quality locally produced rice, sourced from local agricultural producers.',
        'price' => 75,
        'unit' => 'kg',
        'stock' => 250,
        'farmer' => 'Local Farmer',
        'icon' => '🌾'
    ]

];


/*
|--------------------------------------------------------------------------
| INVALID PRODUCT
|--------------------------------------------------------------------------
*/

if ($cropId <= 0 || !isset($crops[$cropId])) {

    header("Location: crops.php");
    exit();

}

$crop = $crops[$cropId];


/*
|--------------------------------------------------------------------------
| LOGIN INFORMATION
|--------------------------------------------------------------------------
*/

$isLoggedIn = isset($_SESSION['user_id']);

$userId = $_SESSION['user_id'] ?? 0;

$userRole = strtolower(
    trim($_SESSION['role'] ?? '')
);


/*
|--------------------------------------------------------------------------
| MESSAGES
|--------------------------------------------------------------------------
*/

$successMessage = '';

$errorMessage = '';


/*
|--------------------------------------------------------------------------
| ADD TO CART
|--------------------------------------------------------------------------
*/

if (
    $_SERVER['REQUEST_METHOD'] === 'POST' &&
    isset($_POST['add_to_cart'])
) {

    /*
    |--------------------------------------------------------------------------
    | CUSTOMER LOGIN CHECK
    |--------------------------------------------------------------------------
    */

    if (!$isLoggedIn || $userRole !== 'customer') {

        header("Location: login.php");
        exit();

    }


    /*
    |--------------------------------------------------------------------------
    | GET QUANTITY
    |--------------------------------------------------------------------------
    */

    $quantity = isset($_POST['quantity'])
        ? (float) $_POST['quantity']
        : 0;


    /*
    |--------------------------------------------------------------------------
    | VALIDATION
    |--------------------------------------------------------------------------
    */

    if ($quantity <= 0) {

        $errorMessage = "Please enter a valid quantity.";

    } elseif ($quantity > $crop['stock']) {

        $errorMessage =
            "Only {$crop['stock']} {$crop['unit']} available.";

    } else {

        /*
        |--------------------------------------------------------------------------
        | FIND CUSTOMER
        |--------------------------------------------------------------------------
        */

        $customerSql = "
            SELECT customer_id
            FROM customers
            WHERE user_id = ?
            LIMIT 1
        ";

        $customerStmt = mysqli_prepare(
            $conn,
            $customerSql
        );


        if (!$customerStmt) {

            $errorMessage =
                "Customer information could not be loaded.";

        } else {

            mysqli_stmt_bind_param(
                $customerStmt,
                "i",
                $userId
            );

            mysqli_stmt_execute(
                $customerStmt
            );

            $customerResult =
                mysqli_stmt_get_result(
                    $customerStmt
                );


            if (
                mysqli_num_rows(
                    $customerResult
                ) === 0
            ) {

                $errorMessage =
                    "Customer profile was not found.";

            } else {

                $customer =
                    mysqli_fetch_assoc(
                        $customerResult
                    );

                $customerId =
                    (int) $customer['customer_id'];


                /*
                |--------------------------------------------------------------------------
                | CHECK EXISTING CART ITEM
                |--------------------------------------------------------------------------
                */

                $checkSql = "
                    SELECT cart_id, quantity
                    FROM cart
                    WHERE customer_id = ?
                    AND crop_id = ?
                    LIMIT 1
                ";

                $checkStmt = mysqli_prepare(
                    $conn,
                    $checkSql
                );


                if (!$checkStmt) {

                    $errorMessage =
                        "Unable to check your cart.";

                } else {

                    mysqli_stmt_bind_param(
                        $checkStmt,
                        "ii",
                        $customerId,
                        $cropId
                    );

                    mysqli_stmt_execute(
                        $checkStmt
                    );

                    $checkResult =
                        mysqli_stmt_get_result(
                            $checkStmt
                        );


                    /*
                    |--------------------------------------------------------------------------
                    | EXISTING ITEM
                    |--------------------------------------------------------------------------
                    */

                    if (
                        mysqli_num_rows(
                            $checkResult
                        ) > 0
                    ) {

                        $existing =
                            mysqli_fetch_assoc(
                                $checkResult
                            );


                        $newQuantity =
                            (float) $existing['quantity']
                            + $quantity;


                        if (
                            $newQuantity >
                            $crop['stock']
                        ) {

                            $errorMessage =
                                "The requested quantity exceeds available stock.";

                        } else {

                            $updateSql = "
                                UPDATE cart
                                SET quantity = ?
                                WHERE cart_id = ?
                                AND customer_id = ?
                            ";

                            $updateStmt =
                                mysqli_prepare(
                                    $conn,
                                    $updateSql
                                );


                            mysqli_stmt_bind_param(
                                $updateStmt,
                                "dii",
                                $newQuantity,
                                $existing['cart_id'],
                                $customerId
                            );


                            if (
                                mysqli_stmt_execute(
                                    $updateStmt
                                )
                            ) {

                                $successMessage =
                                    $crop['name'] .
                                    " quantity updated in your cart.";

                            } else {

                                $errorMessage =
                                    "Unable to update your cart.";

                            }


                            mysqli_stmt_close(
                                $updateStmt
                            );

                        }


                    /*
                    |--------------------------------------------------------------------------
                    | NEW CART ITEM
                    |--------------------------------------------------------------------------
                    */

                    } else {

                        $insertSql = "
                            INSERT INTO cart
                            (
                                customer_id,
                                crop_id,
                                quantity
                            )
                            VALUES
                            (
                                ?,
                                ?,
                                ?
                            )
                        ";

                        $insertStmt =
                            mysqli_prepare(
                                $conn,
                                $insertSql
                            );


                        if (!$insertStmt) {

                            $errorMessage =
                                "Unable to add item to cart.";

                        } else {

                            mysqli_stmt_bind_param(
                                $insertStmt,
                                "iid",
                                $customerId,
                                $cropId,
                                $quantity
                            );


                            if (
                                mysqli_stmt_execute(
                                    $insertStmt
                                )
                            ) {

                                $successMessage =
                                    $crop['name'] .
                                    " added to your cart.";

                            } else {

                                $errorMessage =
                                    "Unable to add item to your cart.";

                            }


                            mysqli_stmt_close(
                                $insertStmt
                            );

                        }

                    }


                    mysqli_stmt_close(
                        $checkStmt
                    );

                }

            }


            mysqli_stmt_close(
                $customerStmt
            );

        }

    }

}

?>


<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Nobanno -
        <?php echo htmlspecialchars($crop['name']); ?>
    </title>


    <!-- =====================================================
         SEPARATE CSS FILE
         product_details.css is directly inside /css
    ====================================================== -->

    <link
        rel="stylesheet"
        href="../css/product_details.css"
    >

</head>


<body>


<!-- =========================================================
     NAVBAR
========================================================= -->

<header class="navbar">


    <!-- LOGO -->

    <a
        href="home.php"
        class="logo"
    >

        <span class="logo-icon">
            🌾
        </span>

        <span>
            নবান্ন
        </span>

    </a>


    <!-- NAVIGATION -->

    <nav class="main-nav">

        <a href="home.php">
            Home
        </a>

        <a
            href="crops.php"
            class="active"
        >
            Crops
        </a>

        <a href="about.php">
            About
        </a>

        <a href="contact.php">
            Contact
        </a>

    </nav>


    <!-- NAV BUTTONS -->

    <div class="nav-buttons">


        <?php if ($isLoggedIn): ?>


            <?php if ($userRole === 'customer'): ?>

                <a
                    href="CustomerDashboard/customer_dashboard.php"
                    class="dashboard-btn"
                >
                    Dashboard
                </a>

            <?php elseif ($userRole === 'admin'): ?>

                <a
                    href="AdminDashboard.php"
                    class="dashboard-btn"
                >
                    Dashboard
                </a>

            <?php endif; ?>


            <a
                href="../logout.php"
                class="login-btn"
            >
                Logout
            </a>


        <?php else: ?>


            <a
                href="login.php"
                class="login-btn"
            >
                Login
            </a>


            <a
                href="register.php"
                class="register-btn"
            >
                Register
            </a>


        <?php endif; ?>


    </div>


</header>



<!-- =========================================================
     MAIN PRODUCT DETAILS
========================================================= -->

<main class="product-details-page">


    <!-- BACK -->

    <a
        href="crops.php"
        class="back-link"
    >
        ← Back to Crops
    </a>



    <!-- PRODUCT CARD -->

    <div class="product-details-card">


        <!-- =================================================
             LEFT SIDE
        ================================================== -->

        <section class="product-visual">


            <span class="fresh-product-badge">
                Fresh Product
            </span>


            <div class="product-big-icon">

                <?php
                echo $crop['icon'];
                ?>

            </div>


        </section>



        <!-- =================================================
             RIGHT SIDE
        ================================================== -->

        <section class="product-details-info">


            <!-- CATEGORY -->

            <span class="product-category">

                <?php
                echo htmlspecialchars(
                    $crop['category']
                );
                ?>

            </span>


            <!-- NAME -->

            <h1>

                <?php
                echo htmlspecialchars(
                    $crop['name']
                );
                ?>

            </h1>


            <!-- DESCRIPTION -->

            <p class="product-description">

                <?php
                echo htmlspecialchars(
                    $crop['description']
                );
                ?>

            </p>


            <!-- PRICE -->

            <div class="product-price-box">

                <span class="product-price">

                    ৳<?php
                    echo number_format(
                        $crop['price'],
                        2
                    );
                    ?>

                </span>


                <span class="product-price-unit">

                    /
                    <?php
                    echo htmlspecialchars(
                        $crop['unit']
                    );
                    ?>

                </span>

            </div>



            <!-- PRODUCT INFORMATION -->

            <div class="product-info-grid">


                <div class="info-box">

                    <span>
                        Available Stock
                    </span>

                    <strong>

                        <?php
                        echo number_format(
                            $crop['stock']
                        );
                        ?>

                        <?php
                        echo htmlspecialchars(
                            $crop['unit']
                        );
                        ?>

                    </strong>

                </div>


                <div class="info-box">

                    <span>
                        Sold By
                    </span>

                    <strong>

                        <?php
                        echo htmlspecialchars(
                            $crop['farmer']
                        );
                        ?>

                    </strong>

                </div>


                <div class="info-box">

                    <span>
                        Category
                    </span>

                    <strong>

                        <?php
                        echo htmlspecialchars(
                            $crop['category']
                        );
                        ?>

                    </strong>

                </div>


                <div class="info-box">

                    <span>
                        Status
                    </span>

                    <strong>
                        Available
                    </strong>

                </div>


            </div>



            <!-- SUCCESS MESSAGE -->

            <?php if ($successMessage !== ''): ?>

                <div
                    class="product-message product-success"
                >

                    ✓
                    <?php
                    echo htmlspecialchars(
                        $successMessage
                    );
                    ?>


                    <a
                        href="CustomerDashboard/cart.php"
                    >
                        View Cart →
                    </a>

                </div>

            <?php endif; ?>



            <!-- ERROR MESSAGE -->

            <?php if ($errorMessage !== ''): ?>

                <div
                    class="product-message product-error"
                >

                    !
                    <?php
                    echo htmlspecialchars(
                        $errorMessage
                    );
                    ?>

                </div>

            <?php endif; ?>



            <!-- ADD TO CART -->

            <div class="add-cart-section">


                <form
                    method="POST"
                    action=""
                >


                    <label
                        for="quantity"
                        class="quantity-label"
                    >

                        Quantity
                        (<?php
                        echo htmlspecialchars(
                            $crop['unit']
                        );
                        ?>)

                    </label>


                    <div class="add-cart-row">


                        <input
                            type="number"
                            id="quantity"
                            name="quantity"
                            class="detail-quantity"
                            value="1"
                            min="0.01"
                            max="<?php
                            echo htmlspecialchars(
                                $crop['stock']
                            );
                            ?>"
                            step="0.01"
                            required
                        >


                        <button
                            type="submit"
                            name="add_to_cart"
                            value="1"
                            class="add-cart-btn"
                        >

                            🛒
                            Add to Cart

                        </button>


                    </div>


                </form>


                <div class="customer-note">

                    <span>
                        🌱
                    </span>

                    <span>
                        Fresh agricultural products
                        sourced from local farmers.
                    </span>

                </div>


            </div>


        </section>


    </div>


</main>



<!-- =========================================================
     FOOTER
========================================================= -->

<footer class="product-footer">


    <div class="product-footer-content">

        <strong>
            🌾 নবান্ন
        </strong>


        <p>
            © <?php echo date('Y'); ?>
            Nobanno Agro-Farm
        </p>

    </div>


</footer>


</body>

</html>