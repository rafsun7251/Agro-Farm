<?php

require_once __DIR__ . '/../admin_auth.php';

require_once __DIR__ . '/../db.php';


// ==========================================
// CHECK DELIVERY ID
// ==========================================

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("Invalid delivery ID.");
}

$delivery_id = (int) $_GET['id'];


// ==========================================
// FETCH DELIVERY INFORMATION
// ==========================================

$query = "
    SELECT
        d.delivery_id,
        d.order_id,
        d.delivery_man_id,
        d.delivery_status,

        o.total_amount,
        o.delivery_address,

        u.first_name AS customer_first_name,
        u.last_name AS customer_last_name

    FROM deliveries d

    INNER JOIN orders o
        ON d.order_id = o.order_id

    INNER JOIN customers c
        ON o.customer_id = c.customer_id

    INNER JOIN users u
        ON c.user_id = u.user_id

    WHERE d.delivery_id = ?
";


$stmt = mysqli_prepare($conn, $query);

mysqli_stmt_bind_param(
    $stmt,
    "i",
    $delivery_id
);

mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);


if (mysqli_num_rows($result) == 0) {
    die("Delivery record not found.");
}

$delivery = mysqli_fetch_assoc($result);


// ==========================================
// FETCH AVAILABLE DELIVERY MEN
// ==========================================

$deliveryMenQuery = "
    SELECT
        dm.delivery_man_id,
        dm.vehicle_type,
        dm.vehicle_number,
        dm.status,

        u.first_name,
        u.last_name,
        u.phone,
        u.email

    FROM delivery_men dm

    INNER JOIN users u
        ON dm.user_id = u.user_id

    WHERE dm.status = 'available'

    ORDER BY u.first_name ASC
";


$deliveryMenResult = mysqli_query(
    $conn,
    $deliveryMenQuery
);


if (!$deliveryMenResult) {

    die(
        "Failed to load delivery men: "
        . mysqli_error($conn)
    );

}


// ==========================================
// FORM PROCESSING
// ==========================================

$errorMessage = "";


if ($_SERVER["REQUEST_METHOD"] === "POST") {

    if (
        !isset(
            $_POST['delivery_man_id']
        )
        ||
        !is_numeric(
            $_POST['delivery_man_id']
        )
    ) {

        $errorMessage =
            "Please select a delivery man.";

    } else {

        $newDeliveryManId =
            (int) $_POST['delivery_man_id'];


        // ==========================================
        // CHECK DELIVERY MAN
        // ==========================================

        $checkQuery = "
            SELECT delivery_man_id
            FROM delivery_men
            WHERE delivery_man_id = ?
            AND status = 'available'
        ";


        $checkStmt = mysqli_prepare(
            $conn,
            $checkQuery
        );


        mysqli_stmt_bind_param(
            $checkStmt,
            "i",
            $newDeliveryManId
        );


        mysqli_stmt_execute(
            $checkStmt
        );


        $checkResult =
            mysqli_stmt_get_result(
                $checkStmt
            );


        if (
            mysqli_num_rows(
                $checkResult
            ) == 0
        ) {

            $errorMessage =
                "Selected delivery man is not available.";

        } else {


            // ==========================================
            // UPDATE DELIVERY
            // ==========================================

            $updateQuery = "
                UPDATE deliveries

                SET
                    delivery_man_id = ?,
                    delivery_status = 'assigned',
                    assigned_at = CURRENT_TIMESTAMP

                WHERE delivery_id = ?
            ";


            $updateStmt = mysqli_prepare(
                $conn,
                $updateQuery
            );


            mysqli_stmt_bind_param(
                $updateStmt,
                "ii",
                $newDeliveryManId,
                $delivery_id
            );


            if (
                mysqli_stmt_execute(
                    $updateStmt
                )
            ) {


                // ==========================================
                // UPDATE DELIVERY MAN STATUS
                // ==========================================

                $busyQuery = "
                    UPDATE delivery_men

                    SET status = 'busy'

                    WHERE delivery_man_id = ?
                ";


                $busyStmt = mysqli_prepare(
                    $conn,
                    $busyQuery
                );


                mysqli_stmt_bind_param(
                    $busyStmt,
                    "i",
                    $newDeliveryManId
                );


                mysqli_stmt_execute(
                    $busyStmt
                );


                // ==========================================
                // REDIRECT
                // ==========================================

                header(
                    "Location: DeliveryManagement.php?assigned=1"
                );

                exit();

            } else {

                $errorMessage =
                    "Failed to assign delivery man: "
                    . mysqli_error($conn);

            }

        }

    }

}

?>

<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Agro-Farm | Assign Delivery
    </title>

    <link
        rel="stylesheet"
        href="../css/AssignDelivery.css"
    >

</head>


<body>


<div class="page-container">


    <!-- ==========================================
         HEADER
    =========================================== -->

    <div class="page-header">


        <div>

            <h1>
                Assign Delivery
            </h1>

            <p>
                Assign a delivery man to Order
                #<?php echo $delivery['order_id']; ?>
            </p>

        </div>


        <a
            href="DeliveryManagement.php"
            class="back-btn"
        >
            ← Back to Deliveries
        </a>


    </div>



    <!-- ==========================================
         MAIN CARD
    =========================================== -->

    <div class="main-card">


        <?php if (!empty($errorMessage)) { ?>

            <div class="error-message">

                <?php

                echo htmlspecialchars(
                    $errorMessage
                );

                ?>

            </div>

        <?php } ?>



        <!-- ==========================================
             ORDER INFORMATION
        =========================================== -->

        <div class="section">


            <h3>
                Order Information
            </h3>


            <div class="order-summary">


                <div class="summary-item">

                    <span>
                        Order ID
                    </span>

                    <strong>
                        #<?php
                        echo $delivery['order_id'];
                        ?>
                    </strong>

                </div>


                <div class="summary-item">

                    <span>
                        Customer
                    </span>

                    <strong>

                        <?php

                        echo htmlspecialchars(
                            $delivery[
                                'customer_first_name'
                            ]
                            . " "
                            .
                            $delivery[
                                'customer_last_name'
                            ]
                        );

                        ?>

                    </strong>

                </div>


                <div class="summary-item">

                    <span>
                        Order Amount
                    </span>

                    <strong class="amount">

                        ৳<?php

                        echo number_format(
                            $delivery[
                                'total_amount'
                            ],
                            2
                        );

                        ?>

                    </strong>

                </div>


                <div class="summary-item address-item">

                    <span>
                        Delivery Address
                    </span>

                    <strong>

                        <?php

                        echo !empty(
                            $delivery[
                                'delivery_address'
                            ]
                        )
                            ? htmlspecialchars(
                                $delivery[
                                    'delivery_address'
                                ]
                            )
                            : "No address provided";

                        ?>

                    </strong>

                </div>


            </div>


        </div>



        <!-- ==========================================
             ASSIGN FORM
        =========================================== -->

        <form
            method="POST"
            action=""
        >


            <div class="section">


                <h3>
                    Select Delivery Man
                </h3>


                <?php

                if (
                    mysqli_num_rows(
                        $deliveryMenResult
                    ) > 0
                ) {

                ?>


                    <div class="delivery-men-list">


                    <?php

                    while (
                        $man =
                        mysqli_fetch_assoc(
                            $deliveryMenResult
                        )
                    ) {

                        $initial =
                            strtoupper(
                                substr(
                                    $man['first_name'],
                                    0,
                                    1
                                )
                            );

                    ?>


                        <label
                            class="delivery-option"
                        >


                            <input
                                type="radio"
                                name="delivery_man_id"
                                value="<?php
                                echo $man[
                                    'delivery_man_id'
                                ];
                                ?>"
                                required
                            >


                            <div
                                class="delivery-avatar"
                            >

                                <?php

                                echo htmlspecialchars(
                                    $initial
                                );

                                ?>

                            </div>


                            <div
                                class="delivery-info"
                            >

                                <strong>

                                    <?php

                                    echo htmlspecialchars(
                                        $man[
                                            'first_name'
                                        ]
                                        . " "
                                        .
                                        $man[
                                            'last_name'
                                        ]
                                    );

                                    ?>

                                </strong>


                                <span>

                                    <?php

                                    echo !empty(
                                        $man['phone']
                                    )
                                        ? htmlspecialchars(
                                            $man['phone']
                                        )
                                        : "No phone";

                                    ?>

                                </span>


                                <small>

                                    <?php

                                    echo !empty(
                                        $man[
                                            'vehicle_type'
                                        ]
                                    )
                                        ? htmlspecialchars(
                                            $man[
                                                'vehicle_type'
                                            ]
                                        )
                                        : "No vehicle";

                                    ?>

                                    <?php

                                    if (
                                        !empty(
                                            $man[
                                                'vehicle_number'
                                            ]
                                        )
                                    ) {

                                        echo " • "
                                            .
                                            htmlspecialchars(
                                                $man[
                                                    'vehicle_number'
                                                ]
                                            );

                                    }

                                    ?>

                                </small>

                            </div>


                            <span
                                class="available-badge"
                            >
                                Available
                            </span>


                        </label>


                    <?php

                    }

                    ?>


                    </div>


                <?php

                } else {

                ?>


                    <div class="no-delivery-men">

                        <div class="empty-icon">
                            🚚
                        </div>

                        <h4>
                            No Available Delivery Men
                        </h4>

                        <p>
                            There are currently no delivery
                            men available for assignment.
                        </p>

                        <a
                            href="UserManagement.php"
                            class="user-btn"
                        >
                            Manage Users
                        </a>

                    </div>


                <?php

                }

                ?>


            </div>



            <!-- ==========================================
                 ACTIONS
            =========================================== -->

            <?php

            if (
                mysqli_num_rows(
                    $deliveryMenResult
                ) > 0
            ) {

            ?>

                <div class="form-actions">


                    <a
                        href="DeliveryManagement.php"
                        class="cancel-btn"
                    >
                        Cancel
                    </a>


                    <button
                        type="submit"
                        class="assign-btn"
                    >
                        Assign Delivery Man
                    </button>


                </div>

            <?php

            }

            ?>


        </form>


    </div>


</div>


</body>

</html>