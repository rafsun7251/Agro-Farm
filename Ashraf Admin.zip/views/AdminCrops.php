<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Nobanno - Crops</title>

    <link rel="stylesheet" href="../css/AdminCrops.css">

</head>


<body>


    <!-- ================= SIDEBAR ================= -->

    <aside class="sidebar">


        <!-- LOGO -->

        <div class="logo-section">

            <div class="logo-icon">
                🌾
            </div>

            <div class="logo-text">

                <h2>নবান্ন</h2>

                <p>Admin Panel</p>

            </div>

        </div>



        <!-- NAVIGATION -->

        <nav class="sidebar-nav">


            <a href="AdminDashboard.php" class="nav-item">

                <span class="nav-icon">📊</span>

                <span>Dashboard</span>

            </a>


            <a href="AdminUsers.php" class="nav-item">

                <span class="nav-icon">👥</span>

                <span>Users</span>

            </a>


            <a href="AdminFarmers.php" class="nav-item">

                <span class="nav-icon">🌾</span>

                <span>Farmers</span>

            </a>


            <a href="AdminDeliveryMen.php" class="nav-item">

                <span class="nav-icon">🚚</span>

                <span>Delivery Men</span>

            </a>


            <a href="AdminCustomers.php" class="nav-item">

                <span class="nav-icon">🛒</span>

                <span>Customers</span>

            </a>


            <a href="AdminCrops.php" class="nav-item active">

                <span class="nav-icon">🥬</span>

                <span>Crops</span>

            </a>


            <a href="AdminOrders.php" class="nav-item">

                <span class="nav-icon">📦</span>

                <span>Orders</span>

            </a>


        </nav>



        <!-- LOGOUT -->

        <div class="sidebar-bottom">

            <a href="#" class="logout-btn">

                <span class="nav-icon">🚪</span>

                <span>Logout</span>

            </a>

        </div>


    </aside>



    <!-- ================= MAIN CONTENT ================= -->

    <main class="main-content">



        <!-- ================= TOP BAR ================= -->

        <header class="topbar">


            <div class="page-title">

                <h1>Crops</h1>

                <p>Manage crops listed by farmers</p>

            </div>



            <div class="admin-profile">


                <div class="profile-icon">
                    A
                </div>


                <div class="profile-info">

                    <strong>Admin</strong>

                    <span>Administrator</span>

                </div>


            </div>


        </header>



        <!-- ================= PAGE CONTENT ================= -->

        <section class="page-content">



            <!-- PAGE HEADER -->

            <div class="content-header">


                <div>

                    <h2>Crop Management</h2>

                    <p>
                        Monitor and manage all crops listed
                        by farmers on Nobanno.
                    </p>

                </div>


                <button class="add-crop-btn">

                    + Add Crop

                </button>


            </div>



            <!-- ================= STATISTICS ================= -->

            <div class="crop-stats">


                <!-- TOTAL CROPS -->

                <div class="stat-card">

                    <div class="stat-icon total-icon">
                        🌾
                    </div>

                    <div class="stat-info">

                        <p>Total Crops</p>

                        <h3>75</h3>

                    </div>

                </div>



                <!-- AVAILABLE -->

                <div class="stat-card">

                    <div class="stat-icon available-icon">
                        ✓
                    </div>

                    <div class="stat-info">

                        <p>Available</p>

                        <h3>61</h3>

                    </div>

                </div>



                <!-- OUT OF STOCK -->

                <div class="stat-card">

                    <div class="stat-icon stock-icon">
                        !
                    </div>

                    <div class="stat-info">

                        <p>Out of Stock</p>

                        <h3>8</h3>

                    </div>

                </div>



                <!-- PENDING -->

                <div class="stat-card">

                    <div class="stat-icon pending-icon">
                        ⏳
                    </div>

                    <div class="stat-info">

                        <p>Pending Approval</p>

                        <h3>6</h3>

                    </div>

                </div>



                <!-- CATEGORIES -->

                <div class="stat-card">

                    <div class="stat-icon category-icon">
                        🥬
                    </div>

                    <div class="stat-info">

                        <p>Categories</p>

                        <h3>12</h3>

                    </div>

                </div>


            </div>



            <!-- ================= FILTER ================= -->

            <div class="filter-section">


                <!-- SEARCH -->

                <div class="search-box">

                    <span>🔍</span>

                    <input
                        type="text"
                        placeholder="Search crop or farmer..."
                    >

                </div>



                <!-- CATEGORY -->

                <select class="category-filter">

                    <option value="all">
                        All Categories
                    </option>

                    <option value="vegetables">
                        Vegetables
                    </option>

                    <option value="fruits">
                        Fruits
                    </option>

                    <option value="rice">
                        Rice & Grains
                    </option>

                    <option value="spices">
                        Spices
                    </option>

                </select>



                <!-- STATUS -->

                <select class="status-filter">

                    <option value="all">
                        All Status
                    </option>

                    <option value="available">
                        Available
                    </option>

                    <option value="pending">
                        Pending
                    </option>

                    <option value="out">
                        Out of Stock
                    </option>

                </select>



                <!-- LOCATION -->

                <select class="location-filter">

                    <option value="all">
                        All Locations
                    </option>

                    <option value="Dhaka">
                        Dhaka
                    </option>

                    <option value="Barisal">
                        Barisal
                    </option>

                    <option value="Bhola">
                        Bhola
                    </option>

                    <option value="Cumilla">
                        Cumilla
                    </option>

                </select>


            </div>



            <!-- ================= CROP TABLE ================= -->

            <div class="crops-card">


                <div class="table-header">


                    <div>

                        <h3>Crop Listings</h3>

                        <p>
                            75 crops listed by farmers
                        </p>

                    </div>


                </div>



                <div class="table-container">


                    <table>


                        <thead>

                            <tr>

                                <th>Crop</th>

                                <th>Farmer</th>

                                <th>Category</th>

                                <th>Quantity</th>

                                <th>Price / Kg</th>

                                <th>Location</th>

                                <th>Status</th>

                                <th>Action</th>

                            </tr>

                        </thead>



                        <tbody>


                            <!-- CROP 1 -->

                            <tr>


                                <td>

                                    <div class="crop-info">


                                        <div class="crop-image">
                                            🍅
                                        </div>


                                        <div>

                                            <strong>
                                                Tomato
                                            </strong>

                                            <span>
                                                ID: #CRP001
                                            </span>

                                        </div>


                                    </div>

                                </td>


                                <td>
                                    Rahim Ahmed
                                </td>


                                <td>
                                    Vegetables
                                </td>


                                <td>
                                    250 Kg
                                </td>


                                <td>
                                    ৳60
                                </td>


                                <td>
                                    Bhola
                                </td>


                                <td>

                                    <span class="status available">
                                        Available
                                    </span>

                                </td>


                                <td>

                                    <button class="action-btn view">
                                        View
                                    </button>

                                    <button class="action-btn edit">
                                        Edit
                                    </button>

                                </td>


                            </tr>



                            <!-- CROP 2 -->

                            <tr>


                                <td>

                                    <div class="crop-info">


                                        <div class="crop-image">
                                            🥔
                                        </div>


                                        <div>

                                            <strong>
                                                Potato
                                            </strong>

                                            <span>
                                                ID: #CRP002
                                            </span>

                                        </div>


                                    </div>

                                </td>


                                <td>
                                    Hasan Ali
                                </td>


                                <td>
                                    Vegetables
                                </td>


                                <td>
                                    500 Kg
                                </td>


                                <td>
                                    ৳45
                                </td>


                                <td>
                                    Barisal
                                </td>


                                <td>

                                    <span class="status available">
                                        Available
                                    </span>

                                </td>


                                <td>

                                    <button class="action-btn view">
                                        View
                                    </button>

                                    <button class="action-btn edit">
                                        Edit
                                    </button>

                                </td>


                            </tr>



                            <!-- CROP 3 -->

                            <tr>


                                <td>

                                    <div class="crop-info">


                                        <div class="crop-image">
                                            🌾
                                        </div>


                                        <div>

                                            <strong>
                                                Rice
                                            </strong>

                                            <span>
                                                ID: #CRP003
                                            </span>

                                        </div>


                                    </div>

                                </td>


                                <td>
                                    Mahmud Hasan
                                </td>


                                <td>
                                    Rice & Grains
                                </td>


                                <td>
                                    1000 Kg
                                </td>


                                <td>
                                    ৳70
                                </td>


                                <td>
                                    Cumilla
                                </td>


                                <td>

                                    <span class="status pending">
                                        Pending
                                    </span>

                                </td>


                                <td>

                                    <button class="action-btn view">
                                        View
                                    </button>

                                    <button class="action-btn approve">
                                        Approve
                                    </button>

                                </td>


                            </tr>



                            <!-- CROP 4 -->

                            <tr>


                                <td>

                                    <div class="crop-info">


                                        <div class="crop-image">
                                            🥭
                                        </div>


                                        <div>

                                            <strong>
                                                Mango
                                            </strong>

                                            <span>
                                                ID: #CRP004
                                            </span>

                                        </div>


                                    </div>

                                </td>


                                <td>
                                    Selim Mia
                                </td>


                                <td>
                                    Fruits
                                </td>


                                <td>
                                    300 Kg
                                </td>


                                <td>
                                    ৳120
                                </td>


                                <td>
                                    Dhaka
                                </td>


                                <td>

                                    <span class="status available">
                                        Available
                                    </span>

                                </td>


                                <td>

                                    <button class="action-btn view">
                                        View
                                    </button>

                                    <button class="action-btn edit">
                                        Edit
                                    </button>

                                </td>


                            </tr>



                            <!-- CROP 5 -->

                            <tr>


                                <td>

                                    <div class="crop-info">


                                        <div class="crop-image">
                                            🌶️
                                        </div>


                                        <div>

                                            <strong>
                                                Chili
                                            </strong>

                                            <span>
                                                ID: #CRP005
                                            </span>

                                        </div>


                                    </div>

                                </td>


                                <td>
                                    Abdul Karim
                                </td>


                                <td>
                                    Spices
                                </td>


                                <td>
                                    0 Kg
                                </td>


                                <td>
                                    ৳180
                                </td>


                                <td>
                                    Bhola
                                </td>


                                <td>

                                    <span class="status out">
                                        Out of Stock
                                    </span>

                                </td>


                                <td>

                                    <button class="action-btn view">
                                        View
                                    </button>

                                    <button class="action-btn edit">
                                        Edit
                                    </button>

                                </td>


                            </tr>


                        </tbody>


                    </table>


                </div>



                <!-- PAGINATION -->

                <div class="pagination">


                    <button class="page-btn">
                        ‹
                    </button>


                    <button class="page-btn current">
                        1
                    </button>


                    <button class="page-btn">
                        2
                    </button>


                    <button class="page-btn">
                        3
                    </button>


                    <span>...</span>


                    <button class="page-btn">
                        8
                    </button>


                    <button class="page-btn">
                        ›
                    </button>


                </div>


            </div>


        </section>


    </main>


</body>

</html>