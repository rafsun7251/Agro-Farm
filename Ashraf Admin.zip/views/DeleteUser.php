<?php
require_once __DIR__ . '/../admin_auth.php';
require_once __DIR__ . '/../db.php';


// Check user ID

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("Invalid user ID.");
}

$user_id = (int) $_GET['id'];


// Check if user exists

$query = "SELECT user_id FROM users WHERE user_id = ?";

$stmt = mysqli_prepare($conn, $query);

mysqli_stmt_bind_param(
    $stmt,
    "i",
    $user_id
);

mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);


if (mysqli_num_rows($result) == 0) {

    die("User not found.");

}


// Delete user

$deleteQuery = "DELETE FROM users WHERE user_id = ?";

$deleteStmt = mysqli_prepare(
    $conn,
    $deleteQuery
);

mysqli_stmt_bind_param(
    $deleteStmt,
    "i",
    $user_id
);


if (mysqli_stmt_execute($deleteStmt)) {

    header("Location: UserManagement.php?deleted=1");

    exit();

} else {

    die(
        "Failed to delete user: "
        . mysqli_error($conn)
    );

}

?>