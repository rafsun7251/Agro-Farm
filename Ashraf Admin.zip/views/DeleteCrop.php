<?php

require_once __DIR__ . '/../admin_auth.php';
require_once __DIR__ . '/../db.php';


// ==========================================
// CHECK CROP ID
// ==========================================

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {

    die("Invalid crop ID.");

}

$crop_id = (int) $_GET['id'];


// ==========================================
// CHECK IF CROP EXISTS
// ==========================================

$query = "
    SELECT crop_id
    FROM crops
    WHERE crop_id = ?
";

$stmt = mysqli_prepare($conn, $query);

mysqli_stmt_bind_param(
    $stmt,
    "i",
    $crop_id
);

mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);


if (mysqli_num_rows($result) == 0) {

    die("Crop not found.");

}


// ==========================================
// DELETE CROP
// ==========================================

$deleteQuery = "
    DELETE FROM crops
    WHERE crop_id = ?
";

$deleteStmt = mysqli_prepare(
    $conn,
    $deleteQuery
);

mysqli_stmt_bind_param(
    $deleteStmt,
    "i",
    $crop_id
);


if (mysqli_stmt_execute($deleteStmt)) {

    header(
        "Location: CropManagement.php?deleted=1"
    );

    exit();

} else {

    die(
        "Failed to delete crop: "
        . mysqli_error($conn)
    );

}

?>