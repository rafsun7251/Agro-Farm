<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Nobanno - Order Details</title>

    <link rel="stylesheet" href="../css/AdminOrderDetails.css">

</head>


<body>


    <!-- ================= SIDEBAR ================= -->

    <aside class="sidebar">


        <div class="logo-section">

            <div class="logo-icon">
                🌾
            </div>

            <div class="logo-text">

                <h2>নবান্ন</h2>

                <p>Admin Panel</p>

            </div>

        </div>



        <nav class="sidebar-nav">


            <a href="AdminDashboard.php" class="nav-item">

                <span class="nav-icon">📊</span>

                <span>Dashboard</span>

            </a>


            <a href="AdminUsers.php" class="nav-item">

                <span class="nav-icon">👥</span>

                <span>Users</span>

            </a>


            <a href="AdminFarmers.php" class="nav-item">

                <span class="nav-icon">🌾</span>

                <span>Farmers</span>

            </a>


            <a href="AdminDeliveryMen.php" class="nav-item">

                <span class="nav-icon">🚚</span>

                <span>Delivery Men</span>

            </a>


            <a href="AdminCustomers.php" class="nav-item">

                <span class="nav-icon">🛒</span>

                <span>Customers</span>

            </a>


            <a href="AdminCrops.php" class="nav-item">

                <span class="nav-icon">🥬</span>

                <span>Crops</span>

            </a>


            <a href="AdminOrders.php" class="nav-item active">

                <span class="nav-icon">📦</span>

                <span>Orders</span>

            </a>


        </nav>



        <div class="sidebar-bottom">

            <a href="#" class="logout-btn">

                <span class="nav-icon">🚪</span>

                <span>Logout</span>

            </a>

        </div>


    </aside>



    <!-- ================= MAIN ================= -->

    <main class="main-content">



        <!-- ================= TOPBAR ================= -->

        <header class="topbar">


            <div class="page-title">

                <h1>Order Details</h1>

                <p>View complete order information</p>

            </div>



            <div class="admin-profile">

                <div class="profile-icon">
                    A
                </div>

                <div class="profile-info">

                    <strong>Admin</strong>

                    <span>Administrator</span>

                </div>

            </div>


        </header>



        <!-- ================= CONTENT ================= -->

        <section class="page-content">


            <!-- BACK -->

            <a href="AdminOrders.php" class="back-btn">

                ← Back to Orders

            </a>



            <!-- ================= ORDER HEADER ================= -->

            <div class="order-header">


                <div>

                    <span class="order-label">
                        ORDER
                    </span>

                    <h2>#ORD001</h2>

                    <p>
                        Placed on 25 August 2026 at 10:35 AM
                    </p>

                </div>


                <div class="header-actions">

                    <span class="status completed">
                        Completed
                    </span>

                    <button class="print-btn">
                        🖨 Print
                    </button>

                </div>


            </div>



            <!-- ================= ORDER TRACKING ================= -->

            <div class="card tracking-card">


                <h3>Order Progress</h3>


                <div class="tracking">


                    <div class="track-step completed-step">

                        <div class="track-circle">
                            ✓
                        </div>

                        <div>

                            <strong>
                                Order Placed
                            </strong>

                            <span>
                                25 Aug, 10:35 AM
                            </span>

                        </div>

                    </div>



                    <div class="track-line completed-line"></div>



                    <div class="track-step completed-step">

                        <div class="track-circle">
                            ✓
                        </div>

                        <div>

                            <strong>
                                Processing
                            </strong>

                            <span>
                                25 Aug, 11:20 AM
                            </span>

                        </div>

                    </div>



                    <div class="track-line completed-line"></div>



                    <div class="track-step completed-step">

                        <div class="track-circle">
                            ✓
                        </div>

                        <div>

                            <strong>
                                Out for Delivery
                            </strong>

                            <span>
                                25 Aug, 2:15 PM
                            </span>

                        </div>

                    </div>



                    <div class="track-line completed-line"></div>



                    <div class="track-step completed-step">

                        <div class="track-circle">
                            ✓
                        </div>

                        <div>

                            <strong>
                                Delivered
                            </strong>

                            <span>
                                25 Aug, 5:40 PM
                            </span>

                        </div>

                    </div>


                </div>


            </div>



            <!-- ================= TWO COLUMN ================= -->

            <div class="details-grid">



                <!-- ================= CUSTOMER ================= -->

                <div class="card">


                    <div class="card-title">

                        <h3>Customer Information</h3>

                    </div>


                    <div class="person-info">


                        <div class="large-avatar">
                            R
                        </div>


                        <div>

                            <h4>Rakib Hasan</h4>

                            <p>Customer ID: #CUS001</p>

                        </div>


                    </div>


                    <div class="info-list">


                        <div>

                            <span>Phone</span>

                            <strong>
                                017XXXXXXXX
                            </strong>

                        </div>


                        <div>

                            <span>Email</span>

                            <strong>
                                rakib@example.com
                            </strong>

                        </div>


                        <div>

                            <span>Delivery Address</span>

                            <strong>
                                Mirpur, Dhaka
                            </strong>

                        </div>


                    </div>


                </div>



                <!-- ================= FARMER ================= -->

                <div class="card">


                    <div class="card-title">

                        <h3>Farmer Information</h3>

                    </div>


                    <div class="person-info">


                        <div class="large-avatar farmer-avatar">
                            R
                        </div>


                        <div>

                            <h4>Rahim Ahmed</h4>

                            <p>Farmer ID: #FAR001</p>

                        </div>


                    </div>


                    <div class="info-list">


                        <div>

                            <span>Phone</span>

                            <strong>
                                018XXXXXXXX
                            </strong>

                        </div>


                        <div>

                            <span>Location</span>

                            <strong>
                                Bhola
                            </strong>

                        </div>


                        <div>

                            <span>Farm</span>

                            <strong>
                                Rahim's Farm
                            </strong>

                        </div>


                    </div>


                </div>



                <!-- ================= CROP ================= -->

                <div class="card crop-card">


                    <div class="card-title">

                        <h3>Crop Information</h3>

                    </div>


                    <div class="crop-details">


                        <div class="crop-image">
                            🍅
                        </div>


                        <div class="crop-name">

                            <h4>Fresh Tomato</h4>

                            <p>Crop ID: #CRP001</p>

                        </div>


                    </div>


                    <div class="info-list">


                        <div>

                            <span>Category</span>

                            <strong>
                                Vegetables
                            </strong>

                        </div>


                        <div>

                            <span>Quantity</span>

                            <strong>
                                10 Kg
                            </strong>

                        </div>


                        <div>

                            <span>Price per Kg</span>

                            <strong>
                                ৳60
                            </strong>

                        </div>


                    </div>


                </div>



                <!-- ================= DELIVERY ================= -->

                <div class="card">


                    <div class="card-title">

                        <h3>Delivery Information</h3>

                    </div>


                    <div class="person-info">


                        <div class="large-avatar delivery-avatar">
                            K
                        </div>


                        <div>

                            <h4>Karim Uddin</h4>

                            <p>Delivery Man: #DEL001</p>

                        </div>


                    </div>


                    <div class="info-list">


                        <div>

                            <span>Phone</span>

                            <strong>
                                019XXXXXXXX
                            </strong>

                        </div>


                        <div>

                            <span>Vehicle</span>

                            <strong>
                                Motorcycle
                            </strong>

                        </div>


                        <div>

                            <span>Delivery Status</span>

                            <strong class="success-text">
                                Delivered
                            </strong>

                        </div>


                    </div>


                </div>


            </div>



            <!-- ================= PAYMENT ================= -->

            <div class="card payment-card">


                <div class="card-title">

                    <h3>Payment Summary</h3>

                    <span class="payment-status">
                        PAID
                    </span>

                </div>


                <div class="payment-table">


                    <div class="payment-row">

                        <span>
                            Tomato
                        </span>

                        <span>
                            10 Kg × ৳60
                        </span>

                        <strong>
                            ৳600
                        </strong>

                    </div>


                    <div class="payment-row">

                        <span>
                            Delivery Charge
                        </span>

                        <span>
                            -
                        </span>

                        <strong>
                            ৳50
                        </strong>

                    </div>


                    <div class="payment-row">

                        <span>
                            Platform Fee
                        </span>

                        <span>
                            -
                        </span>

                        <strong>
                            ৳20
                        </strong>

                    </div>


                    <div class="payment-row total-row">

                        <strong>
                            Total
                        </strong>

                        <span></span>

                        <strong>
                            ৳670
                        </strong>

                    </div>


                </div>


                <div class="payment-method">

                    <span>Payment Method</span>

                    <strong>
                        bKash
                    </strong>

                </div>


            </div>



            <!-- ================= ADMIN ACTIONS ================= -->

            <div class="admin-actions">


                <button class="action cancel">
                    Cancel Order
                </button>


                <button class="action assign">
                    Assign Delivery Man
                </button>


                <button class="action update">
                    Update Status
                </button>


            </div>


        </section>


    </main>


</body>

</html>