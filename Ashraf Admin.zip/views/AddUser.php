<?php



require_once __DIR__ . '/../admin_auth.php';
require_once __DIR__ . '/../db.php';

$message = "";
$messageType = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $first_name = trim($_POST["first_name"]);
    $last_name = trim($_POST["last_name"]);
    $email = trim($_POST["email"]);
    $password = $_POST["password"];
    $phone = trim($_POST["phone"]);
    $role = $_POST["role"];

    /*
    ==========================================
    BASIC VALIDATION
    ==========================================
    */

    if (
        empty($first_name) ||
        empty($last_name) ||
        empty($email) ||
        empty($password) ||
        empty($role)
    ) {

        $message = "Please fill in all required fields.";
        $messageType = "error";

    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {

        $message = "Please enter a valid email address.";
        $messageType = "error";

    } elseif (strlen($password) < 6) {

        $message = "Password must be at least 6 characters.";
        $messageType = "error";

    } else {

        /*
        ==========================================
        CHECK EMAIL
        ==========================================
        */

        $checkQuery = "SELECT user_id FROM users WHERE email = ?";

        $checkStmt = mysqli_prepare($conn, $checkQuery);

        mysqli_stmt_bind_param(
            $checkStmt,
            "s",
            $email
        );

        mysqli_stmt_execute($checkStmt);

        $checkResult = mysqli_stmt_get_result($checkStmt);


        if (mysqli_num_rows($checkResult) > 0) {

            $message = "This email is already registered.";
            $messageType = "error";

        } else {

            /*
            ==========================================
            PASSWORD HASH
            ==========================================
            */

            $hashedPassword = password_hash(
                $password,
                PASSWORD_DEFAULT
            );


            /*
            ==========================================
            INSERT USER
            ==========================================
            */

            $insertQuery = "
                INSERT INTO users
                (
                    first_name,
                    last_name,
                    email,
                    password,
                    role,
                    phone
                )
                VALUES (?, ?, ?, ?, ?, ?)
            ";

            $insertStmt = mysqli_prepare(
                $conn,
                $insertQuery
            );

            mysqli_stmt_bind_param(
                $insertStmt,
                "ssssss",
                $first_name,
                $last_name,
                $email,
                $hashedPassword,
                $role,
                $phone
            );


            if (mysqli_stmt_execute($insertStmt)) {

                $user_id = mysqli_insert_id($conn);


                /*
                ==========================================
                CREATE ROLE-SPECIFIC RECORD
                ==========================================
                */

                if ($role == "farmer") {

                    $farm_name = trim($_POST["farm_name"] ?? "");
                    $location = trim($_POST["location"] ?? "");
                    $address = trim($_POST["address"] ?? "");

                    $query = "
                        INSERT INTO farmers
                        (
                            user_id,
                            farm_name,
                            location,
                            address
                        )
                        VALUES (?, ?, ?, ?)
                    ";

                    $stmt = mysqli_prepare(
                        $conn,
                        $query
                    );

                    mysqli_stmt_bind_param(
                        $stmt,
                        "isss",
                        $user_id,
                        $farm_name,
                        $location,
                        $address
                    );

                    mysqli_stmt_execute($stmt);


                } elseif ($role == "customer") {

                    $address = trim($_POST["address"] ?? "");

                    $query = "
                        INSERT INTO customers
                        (
                            user_id,
                            address
                        )
                        VALUES (?, ?)
                    ";

                    $stmt = mysqli_prepare(
                        $conn,
                        $query
                    );

                    mysqli_stmt_bind_param(
                        $stmt,
                        "is",
                        $user_id,
                        $address
                    );

                    mysqli_stmt_execute($stmt);


                } elseif ($role == "delivery_man") {

                    $vehicle_type = trim(
                        $_POST["vehicle_type"] ?? ""
                    );

                    $vehicle_number = trim(
                        $_POST["vehicle_number"] ?? ""
                    );

                    $query = "
                        INSERT INTO delivery_men
                        (
                            user_id,
                            vehicle_type,
                            vehicle_number
                        )
                        VALUES (?, ?, ?)
                    ";

                    $stmt = mysqli_prepare(
                        $conn,
                        $query
                    );

                    mysqli_stmt_bind_param(
                        $stmt,
                        "iss",
                        $user_id,
                        $vehicle_type,
                        $vehicle_number
                    );

                    mysqli_stmt_execute($stmt);
                }


                $message = "User created successfully.";
                $messageType = "success";


                /*
                Clear form values
                */

                $first_name = "";
                $last_name = "";
                $email = "";
                $phone = "";

            } else {

                $message = "Failed to create user.";
                $messageType = "error";
            }
        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Agro-Farm | Add User</title>

    <link
        rel="stylesheet"
        href="../css/AddUser.css"
    >

</head>


<body>

<div class="page-container">


    <!-- ==========================================
         HEADER
    =========================================== -->

    <div class="page-header">

        <div>

            <h1>Add New User</h1>

            <p>
                Create a new Agro-Farm account
            </p>

        </div>


        <a
            href="UserManagement.php"
            class="back-btn"
        >
            ← Back to Users
        </a>

    </div>



    <!-- ==========================================
         MESSAGE
    =========================================== -->

    <?php if (!empty($message)) { ?>

        <div class="message <?php echo $messageType; ?>">

            <?php echo htmlspecialchars($message); ?>

        </div>

    <?php } ?>



    <!-- ==========================================
         FORM
    =========================================== -->

    <div class="form-card">

        <form
            method="POST"
            action=""
        >


            <!-- BASIC INFORMATION -->

            <div class="section-title">

                <h3>Basic Information</h3>

                <p>
                    Enter the user's personal information.
                </p>

            </div>


            <div class="form-grid">


                <div class="form-group">

                    <label>
                        First Name
                        <span>*</span>
                    </label>

                    <input
                        type="text"
                        name="first_name"
                        placeholder="Enter first name"
                        value="<?php
                            echo htmlspecialchars(
                                $first_name ?? ""
                            );
                        ?>"
                        required
                    >

                </div>


                <div class="form-group">

                    <label>
                        Last Name
                        <span>*</span>
                    </label>

                    <input
                        type="text"
                        name="last_name"
                        placeholder="Enter last name"
                        value="<?php
                            echo htmlspecialchars(
                                $last_name ?? ""
                            );
                        ?>"
                        required
                    >

                </div>


                <div class="form-group">

                    <label>
                        Email
                        <span>*</span>
                    </label>

                    <input
                        type="email"
                        name="email"
                        placeholder="example@email.com"
                        value="<?php
                            echo htmlspecialchars(
                                $email ?? ""
                            );
                        ?>"
                        required
                    >

                </div>


                <div class="form-group">

                    <label>
                        Phone
                    </label>

                    <input
                        type="text"
                        name="phone"
                        placeholder="01XXXXXXXXX"
                        value="<?php
                            echo htmlspecialchars(
                                $phone ?? ""
                            );
                        ?>"
                    >

                </div>


                <div class="form-group">

                    <label>
                        Password
                        <span>*</span>
                    </label>

                    <input
                        type="password"
                        name="password"
                        placeholder="Minimum 6 characters"
                        required
                    >

                </div>


                <div class="form-group">

                    <label>
                        Role
                        <span>*</span>
                    </label>

                    <select
                        name="role"
                        id="role"
                        required
                        onchange="showRoleFields()"
                    >

                        <option value="">
                            Select Role
                        </option>

                        <option value="admin">
                            Admin
                        </option>

                        <option value="farmer">
                            Farmer
                        </option>

                        <option value="delivery_man">
                            Delivery Man
                        </option>

                        <option value="customer">
                            Customer
                        </option>

                    </select>

                </div>

            </div>



            <!-- ==========================================
                 FARMER INFORMATION
            =========================================== -->

            <div
                class="role-section"
                id="farmerFields"
            >

                <div class="section-title">

                    <h3>Farmer Information</h3>

                    <p>
                        Additional information for the farmer.
                    </p>

                </div>


                <div class="form-grid">

                    <div class="form-group">

                        <label>Farm Name</label>

                        <input
                            type="text"
                            name="farm_name"
                            placeholder="Enter farm name"
                        >

                    </div>


                    <div class="form-group">

                        <label>Location</label>

                        <input
                            type="text"
                            name="location"
                            placeholder="District / Area"
                        >

                    </div>


                    <div class="form-group full-width">

                        <label>Address</label>

                        <textarea
                            name="address"
                            placeholder="Enter farm address"
                        ></textarea>

                    </div>

                </div>

            </div>



            <!-- ==========================================
                 DELIVERY INFORMATION
            =========================================== -->

            <div
                class="role-section"
                id="deliveryFields"
            >

                <div class="section-title">

                    <h3>Delivery Man Information</h3>

                    <p>
                        Enter vehicle information.
                    </p>

                </div>


                <div class="form-grid">

                    <div class="form-group">

                        <label>Vehicle Type</label>

                        <input
                            type="text"
                            name="vehicle_type"
                            placeholder="Bike / Van / Truck"
                        >

                    </div>


                    <div class="form-group">

                        <label>Vehicle Number</label>

                        <input
                            type="text"
                            name="vehicle_number"
                            placeholder="Vehicle number"
                        >

                    </div>

                </div>

            </div>



            <!-- ==========================================
                 CUSTOMER INFORMATION
            =========================================== -->

            <div
                class="role-section"
                id="customerFields"
            >

                <div class="section-title">

                    <h3>Customer Information</h3>

                    <p>
                        Enter customer's delivery address.
                    </p>

                </div>


                <div class="form-grid">

                    <div class="form-group full-width">

                        <label>Address</label>

                        <textarea
                            name="address"
                            placeholder="Enter customer address"
                        ></textarea>

                    </div>

                </div>

            </div>



            <!-- ==========================================
                 BUTTONS
            =========================================== -->

            <div class="form-actions">

                <a
                    href="UserManagement.php"
                    class="cancel-btn"
                >
                    Cancel
                </a>


                <button
                    type="submit"
                    class="save-btn"
                >
                    Create User
                </button>

            </div>


        </form>

    </div>

</div>



<script>

function showRoleFields() {

    const role =
        document.getElementById("role").value;


    document.getElementById(
        "farmerFields"
    ).style.display = "none";


    document.getElementById(
        "deliveryFields"
    ).style.display = "none";


    document.getElementById(
        "customerFields"
    ).style.display = "none";


    if (role === "farmer") {

        document.getElementById(
            "farmerFields"
        ).style.display = "block";

    }


    if (role === "delivery_man") {

        document.getElementById(
            "deliveryFields"
        ).style.display = "block";

    }


    if (role === "customer") {

        document.getElementById(
            "customerFields"
        ).style.display = "block";

    }

}

</script>

</body>

</html>