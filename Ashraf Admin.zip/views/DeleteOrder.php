<?php

require_once __DIR__ . '/../admin_auth.php';

require_once __DIR__ . '/../db.php';



// ==========================================
// CHECK ORDER ID
// ==========================================

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {

    die("Invalid order ID.");

}

$order_id = (int) $_GET['id'];


// ==========================================
// CHECK IF ORDER EXISTS
// ==========================================

$query = "
    SELECT order_id
    FROM orders
    WHERE order_id = ?
";

$stmt = mysqli_prepare($conn, $query);

mysqli_stmt_bind_param(
    $stmt,
    "i",
    $order_id
);

mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);


if (mysqli_num_rows($result) == 0) {

    die("Order not found.");

}


// ==========================================
// DELETE ORDER
// ==========================================

$deleteQuery = "
    DELETE FROM orders
    WHERE order_id = ?
";

$deleteStmt = mysqli_prepare(
    $conn,
    $deleteQuery
);

mysqli_stmt_bind_param(
    $deleteStmt,
    "i",
    $order_id
);


if (mysqli_stmt_execute($deleteStmt)) {

    header(
        "Location: OrderManagement.php?deleted=1"
    );

    exit();

} else {

    die(
        "Failed to delete order: "
        . mysqli_error($conn)
    );

}

?>