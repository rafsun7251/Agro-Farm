<?php

require_once __DIR__ . '/../admin_auth.php';
require_once __DIR__ . '/../db.php';

$message = "";
$messageType = "";

/* ==========================================
   GET USER ID
========================================== */

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("Invalid user ID.");
}

$user_id = (int) $_GET['id'];


/* ==========================================
   FETCH USER
========================================== */

$query = "
    SELECT
        user_id,
        first_name,
        last_name,
        email,
        role,
        phone
    FROM users
    WHERE user_id = ?
";

$stmt = mysqli_prepare($conn, $query);

mysqli_stmt_bind_param(
    $stmt,
    "i",
    $user_id
);

mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);

$user = mysqli_fetch_assoc($result);

if (!$user) {
    die("User not found.");
}


/* ==========================================
   UPDATE USER
========================================== */

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $first_name = trim($_POST["first_name"]);
    $last_name = trim($_POST["last_name"]);
    $email = trim($_POST["email"]);
    $phone = trim($_POST["phone"]);
    $role = $_POST["role"];
    $password = $_POST["password"];


    /* BASIC VALIDATION */

    if (
        empty($first_name) ||
        empty($last_name) ||
        empty($email) ||
        empty($role)
    ) {

        $message = "Please fill in all required fields.";
        $messageType = "error";

    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {

        $message = "Please enter a valid email address.";
        $messageType = "error";

    } else {

        /* ==========================================
           CHECK DUPLICATE EMAIL
        ========================================== */

        $checkQuery = "
            SELECT user_id
            FROM users
            WHERE email = ?
            AND user_id != ?
        ";

        $checkStmt = mysqli_prepare(
            $conn,
            $checkQuery
        );

        mysqli_stmt_bind_param(
            $checkStmt,
            "si",
            $email,
            $user_id
        );

        mysqli_stmt_execute($checkStmt);

        $checkResult = mysqli_stmt_get_result(
            $checkStmt
        );


        if (mysqli_num_rows($checkResult) > 0) {

            $message = "This email is already used by another user.";
            $messageType = "error";

        } else {

            /* ==========================================
               UPDATE WITH PASSWORD
            ========================================== */

            if (!empty($password)) {

                if (strlen($password) < 6) {

                    $message = "Password must be at least 6 characters.";
                    $messageType = "error";

                } else {

                    $hashedPassword = password_hash(
                        $password,
                        PASSWORD_DEFAULT
                    );

                    $updateQuery = "
                        UPDATE users
                        SET
                            first_name = ?,
                            last_name = ?,
                            email = ?,
                            password = ?,
                            role = ?,
                            phone = ?
                        WHERE user_id = ?
                    ";

                    $updateStmt = mysqli_prepare(
                        $conn,
                        $updateQuery
                    );

                    mysqli_stmt_bind_param(
                        $updateStmt,
                        "ssssssi",
                        $first_name,
                        $last_name,
                        $email,
                        $hashedPassword,
                        $role,
                        $phone,
                        $user_id
                    );

                    mysqli_stmt_execute($updateStmt);

                    $message = "User updated successfully.";
                    $messageType = "success";
                }

            } else {

                /* ==========================================
                   UPDATE WITHOUT PASSWORD
                ========================================== */

                $updateQuery = "
                    UPDATE users
                    SET
                        first_name = ?,
                        last_name = ?,
                        email = ?,
                        role = ?,
                        phone = ?
                    WHERE user_id = ?
                ";

                $updateStmt = mysqli_prepare(
                    $conn,
                    $updateQuery
                );

                mysqli_stmt_bind_param(
                    $updateStmt,
                    "sssssi",
                    $first_name,
                    $last_name,
                    $email,
                    $role,
                    $phone,
                    $user_id
                );

                mysqli_stmt_execute($updateStmt);

                $message = "User updated successfully.";
                $messageType = "success";
            }


            /* ==========================================
               UPDATE LOCAL VALUES
            ========================================== */

            if ($messageType == "success") {

                $user['first_name'] = $first_name;
                $user['last_name'] = $last_name;
                $user['email'] = $email;
                $user['role'] = $role;
                $user['phone'] = $phone;
            }
        }
    }
}

?>

<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Agro-Farm | Edit User</title>

    <link
        rel="stylesheet"
        href="../css/AddUser.css"
    >

</head>


<body>

<div class="page-container">


    <!-- HEADER -->

    <div class="page-header">

        <div>

            <h1>Edit User</h1>

            <p>
                Update Agro-Farm user information
            </p>

        </div>


        <a
            href="UserManagement.php"
            class="back-btn"
        >
            ← Back to Users
        </a>

    </div>


    <!-- MESSAGE -->

    <?php if (!empty($message)) { ?>

        <div class="message <?php echo $messageType; ?>">

            <?php
            echo htmlspecialchars($message);
            ?>

        </div>

    <?php } ?>


    <!-- FORM -->

    <div class="form-card">

        <form method="POST">


            <div class="section-title">

                <h3>User Information</h3>

                <p>
                    Update the user's account information.
                </p>

            </div>


            <div class="form-grid">


                <!-- FIRST NAME -->

                <div class="form-group">

                    <label>
                        First Name
                        <span>*</span>
                    </label>

                    <input
                        type="text"
                        name="first_name"
                        value="<?php
                            echo htmlspecialchars(
                                $user['first_name']
                            );
                        ?>"
                        required
                    >

                </div>


                <!-- LAST NAME -->

                <div class="form-group">

                    <label>
                        Last Name
                        <span>*</span>
                    </label>

                    <input
                        type="text"
                        name="last_name"
                        value="<?php
                            echo htmlspecialchars(
                                $user['last_name']
                            );
                        ?>"
                        required
                    >

                </div>


                <!-- EMAIL -->

                <div class="form-group">

                    <label>
                        Email
                        <span>*</span>
                    </label>

                    <input
                        type="email"
                        name="email"
                        value="<?php
                            echo htmlspecialchars(
                                $user['email']
                            );
                        ?>"
                        required
                    >

                </div>


                <!-- PHONE -->

                <div class="form-group">

                    <label>
                        Phone
                    </label>

                    <input
                        type="text"
                        name="phone"
                        value="<?php
                            echo htmlspecialchars(
                                $user['phone'] ?? ''
                            );
                        ?>"
                    >

                </div>


                <!-- ROLE -->

                <div class="form-group">

                    <label>
                        Role
                        <span>*</span>
                    </label>

                    <select
                        name="role"
                        required
                    >

                        <option
                            value="admin"
                            <?php
                            if ($user['role'] == 'admin')
                                echo 'selected';
                            ?>
                        >
                            Admin
                        </option>

                        <option
                            value="farmer"
                            <?php
                            if ($user['role'] == 'farmer')
                                echo 'selected';
                            ?>
                        >
                            Farmer
                        </option>

                        <option
                            value="delivery_man"
                            <?php
                            if ($user['role'] == 'delivery_man')
                                echo 'selected';
                            ?>
                        >
                            Delivery Man
                        </option>

                        <option
                            value="customer"
                            <?php
                            if ($user['role'] == 'customer')
                                echo 'selected';
                            ?>
                        >
                            Customer
                        </option>

                    </select>

                </div>


                <!-- PASSWORD -->

                <div class="form-group">

                    <label>
                        New Password
                    </label>

                    <input
                        type="password"
                        name="password"
                        placeholder="Leave blank to keep current password"
                    >

                </div>

            </div>


            <!-- BUTTONS -->

            <div class="form-actions">

                <a
                    href="UserManagement.php"
                    class="cancel-btn"
                >
                    Cancel
                </a>


                <button
                    type="submit"
                    class="save-btn"
                >
                    Update User
                </button>

            </div>


        </form>

    </div>

</div>

</body>

</html>