<?php

require_once __DIR__ . '/../admin_auth.php';

require_once __DIR__ . '/../db.php';


// ==========================================
// CHECK ORDER ID
// ==========================================

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("Invalid order ID.");
}

$order_id = (int) $_GET['id'];


// ==========================================
// FETCH ORDER
// ==========================================

$query = "
    SELECT
        o.order_id,
        o.order_date,
        o.total_amount,
        o.delivery_charge,
        o.platform_fee,
        o.status,
        o.delivery_address,

        c.customer_id,

        u.first_name,
        u.last_name,
        u.email,
        u.phone

    FROM orders o

    INNER JOIN customers c
        ON o.customer_id = c.customer_id

    INNER JOIN users u
        ON c.user_id = u.user_id

    WHERE o.order_id = ?
";


$stmt = mysqli_prepare($conn, $query);

mysqli_stmt_bind_param(
    $stmt,
    "i",
    $order_id
);

mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);


if (mysqli_num_rows($result) == 0) {
    die("Order not found.");
}


$order = mysqli_fetch_assoc($result);


// ==========================================
// UPDATE ORDER
// ==========================================

$errorMessage = "";


if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $status = $_POST['status'];

    $delivery_charge = $_POST['delivery_charge'];

    $platform_fee = $_POST['platform_fee'];

    $delivery_address = trim(
        $_POST['delivery_address']
    );


    // ==========================================
    // VALIDATION
    // ==========================================

    $validStatuses = [
        'pending',
        'processing',
        'out_for_delivery',
        'completed',
        'cancelled'
    ];


    if (!in_array($status, $validStatuses)) {

        $errorMessage = "Invalid order status.";

    } elseif (
        !is_numeric($delivery_charge) ||
        $delivery_charge < 0
    ) {

        $errorMessage = "Please enter a valid delivery charge.";

    } elseif (
        !is_numeric($platform_fee) ||
        $platform_fee < 0
    ) {

        $errorMessage = "Please enter a valid platform fee.";

    } else {

        // ==========================================
        // UPDATE DATABASE
        // ==========================================

        $updateQuery = "
            UPDATE orders

            SET
                delivery_charge = ?,
                platform_fee = ?,
                status = ?,
                delivery_address = ?

            WHERE order_id = ?
        ";


        $updateStmt = mysqli_prepare(
            $conn,
            $updateQuery
        );


        mysqli_stmt_bind_param(
            $updateStmt,
            "ddssi",
            $delivery_charge,
            $platform_fee,
            $status,
            $delivery_address,
            $order_id
        );


        if (mysqli_stmt_execute($updateStmt)) {

            header(
                "Location: OrderManagement.php?updated=1"
            );

            exit();

        } else {

            $errorMessage =
                "Failed to update order: "
                . mysqli_error($conn);

        }

    }

}

?>

<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Agro-Farm | Edit Order
    </title>

    <link
        rel="stylesheet"
        href="../css/EditOrder.css"
    >

</head>


<body>


<div class="page-container">


    <!-- ==========================================
         HEADER
    =========================================== -->

    <div class="page-header">

        <div>

            <h1>
                Edit Order #<?php
                echo $order_id;
                ?>
            </h1>

            <p>
                Update order information
            </p>

        </div>


        <a
            href="OrderManagement.php"
            class="back-btn"
        >
            ← Back to Orders
        </a>

    </div>



    <!-- ==========================================
         FORM CARD
    =========================================== -->

    <div class="form-card">


        <?php if (!empty($errorMessage)) { ?>

            <div class="error-message">

                <?php
                echo htmlspecialchars(
                    $errorMessage
                );
                ?>

            </div>

        <?php } ?>



        <!-- ==========================================
             CUSTOMER INFORMATION
        =========================================== -->

        <div class="section">

            <h3>
                Customer Information
            </h3>


            <div class="info-grid">


                <div class="info-item">

                    <label>
                        Customer
                    </label>

                    <p>

                        <?php

                        echo htmlspecialchars(
                            $order['first_name']
                            . " "
                            . $order['last_name']
                        );

                        ?>

                    </p>

                </div>


                <div class="info-item">

                    <label>
                        Email
                    </label>

                    <p>

                        <?php

                        echo htmlspecialchars(
                            $order['email']
                        );

                        ?>

                    </p>

                </div>


                <div class="info-item">

                    <label>
                        Phone
                    </label>

                    <p>

                        <?php

                        echo !empty(
                            $order['phone']
                        )
                            ? htmlspecialchars(
                                $order['phone']
                            )
                            : "No phone";

                        ?>

                    </p>

                </div>


                <div class="info-item">

                    <label>
                        Order Date
                    </label>

                    <p>

                        <?php

                        echo date(
                            "d M Y, h:i A",
                            strtotime(
                                $order['order_date']
                            )
                        );

                        ?>

                    </p>

                </div>


            </div>

        </div>



        <!-- ==========================================
             ORDER FORM
        =========================================== -->

        <form
            method="POST"
            action=""
        >


            <div class="section">

                <h3>
                    Order Information
                </h3>


                <!-- STATUS -->

                <div class="form-group">

                    <label for="status">

                        Order Status
                        <span>*</span>

                    </label>


                    <select
                        id="status"
                        name="status"
                        required
                    >

                        <option
                            value="pending"
                            <?php

                            if (
                                $order['status']
                                === 'pending'
                            ) {
                                echo 'selected';
                            }

                            ?>
                        >
                            Pending
                        </option>


                        <option
                            value="processing"
                            <?php

                            if (
                                $order['status']
                                === 'processing'
                            ) {
                                echo 'selected';
                            }

                            ?>
                        >
                            Processing
                        </option>


                        <option
                            value="out_for_delivery"
                            <?php

                            if (
                                $order['status']
                                === 'out_for_delivery'
                            ) {
                                echo 'selected';
                            }

                            ?>
                        >
                            Out for Delivery
                        </option>


                        <option
                            value="completed"
                            <?php

                            if (
                                $order['status']
                                === 'completed'
                            ) {
                                echo 'selected';
                            }

                            ?>
                        >
                            Completed
                        </option>


                        <option
                            value="cancelled"
                            <?php

                            if (
                                $order['status']
                                === 'cancelled'
                            ) {
                                echo 'selected';
                            }

                            ?>
                        >
                            Cancelled
                        </option>

                    </select>

                </div>



                <!-- DELIVERY CHARGE + PLATFORM FEE -->

                <div class="form-row">


                    <div class="form-group">

                        <label for="delivery_charge">

                            Delivery Charge
                            <span>*</span>

                        </label>


                        <input
                            type="number"
                            id="delivery_charge"
                            name="delivery_charge"
                            step="0.01"
                            min="0"
                            value="<?php

                            echo htmlspecialchars(
                                $order['delivery_charge']
                            );

                            ?>"
                            required
                        >

                    </div>



                    <div class="form-group">

                        <label for="platform_fee">

                            Platform Fee
                            <span>*</span>

                        </label>


                        <input
                            type="number"
                            id="platform_fee"
                            name="platform_fee"
                            step="0.01"
                            min="0"
                            value="<?php

                            echo htmlspecialchars(
                                $order['platform_fee']
                            );

                            ?>"
                            required
                        >

                    </div>


                </div>



                <!-- TOTAL -->

                <div class="total-box">

                    <span>
                        Current Order Total
                    </span>

                    <strong>

                        ৳<?php

                        echo number_format(
                            $order['total_amount'],
                            2
                        );

                        ?>

                    </strong>

                </div>



                <!-- ADDRESS -->

                <div class="form-group">

                    <label for="delivery_address">

                        Delivery Address

                    </label>


                    <textarea
                        id="delivery_address"
                        name="delivery_address"
                        rows="4"
                    ><?php

                    echo htmlspecialchars(
                        $order['delivery_address']
                    );

                    ?></textarea>

                </div>


            </div>



            <!-- ==========================================
                 BUTTONS
            =========================================== -->

            <div class="form-actions">


                <a
                    href="OrderManagement.php"
                    class="cancel-btn"
                >
                    Cancel
                </a>


                <button
                    type="submit"
                    class="save-btn"
                >
                    Update Order
                </button>


            </div>


        </form>


    </div>


</div>


</body>

</html>