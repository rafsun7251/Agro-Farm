<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Nobanno - Users</title>

    <link rel="stylesheet" href="../css/AdminUsers.css">

</head>


<body>


    <!-- ================= SIDEBAR ================= -->

    <aside class="sidebar">


        <!-- LOGO -->

        <div class="logo-section">

            <div class="logo-icon">
                🌾
            </div>

            <div class="logo-text">

                <h2>নবান্ন</h2>

                <p>Admin Panel</p>

            </div>

        </div>



        <!-- NAVIGATION -->

        <nav class="sidebar-nav">


            <a href="AdminDashboard.php" class="nav-item">

                <span class="nav-icon">📊</span>

                <span>Dashboard</span>

            </a>


            <a href="AdminUsers.php" class="nav-item active">

                <span class="nav-icon">👥</span>

                <span>Users</span>

            </a>


            <a href="#" class="nav-item">

                <span class="nav-icon">🌾</span>

                <span>Farmers</span>

            </a>


            <a href="#" class="nav-item">

                <span class="nav-icon">🚚</span>

                <span>Delivery Men</span>

            </a>


            <a href="#" class="nav-item">

                <span class="nav-icon">🛒</span>

                <span>Customers</span>

            </a>


            <a href="#" class="nav-item">

                <span class="nav-icon">🥬</span>

                <span>Crops</span>

            </a>


            <a href="#" class="nav-item">

                <span class="nav-icon">📦</span>

                <span>Orders</span>

            </a>


        </nav>



        <!-- LOGOUT -->

        <div class="sidebar-bottom">

            <a href="#" class="logout-btn">

                <span class="nav-icon">🚪</span>

                <span>Logout</span>

            </a>

        </div>


    </aside>



    <!-- ================= MAIN CONTENT ================= -->

    <main class="main-content">



        <!-- TOP BAR -->

        <header class="topbar">


            <div class="page-title">

                <h1>Users</h1>

                <p>Manage all Nobanno users</p>

            </div>



            <div class="admin-profile">


                <div class="profile-icon">
                    A
                </div>


                <div class="profile-info">

                    <strong>Admin</strong>

                    <span>Administrator</span>

                </div>


            </div>


        </header>



        <!-- ================= PAGE CONTENT ================= -->

        <section class="page-content">



            <!-- PAGE HEADER -->

            <div class="content-header">


                <div>

                    <h2>All Users</h2>

                    <p>
                        View and manage Admins, Farmers,
                        Delivery Men and Customers.
                    </p>

                </div>


                <button class="add-user-btn">

                    + Add User

                </button>


            </div>



            <!-- ================= USER STATISTICS ================= -->

            <div class="user-stats">


                <div class="mini-card">

                    <div class="mini-icon total">
                        👥
                    </div>

                    <div>

                        <p>Total Users</p>

                        <h3>151</h3>

                    </div>

                </div>



                <div class="mini-card">

                    <div class="mini-icon admin">
                        👑
                    </div>

                    <div>

                        <p>Admins</p>

                        <h3>1</h3>

                    </div>

                </div>



                <div class="mini-card">

                    <div class="mini-icon farmer">
                        🌾
                    </div>

                    <div>

                        <p>Farmers</p>

                        <h3>40</h3>

                    </div>

                </div>



                <div class="mini-card">

                    <div class="mini-icon delivery">
                        🚚
                    </div>

                    <div>

                        <p>Delivery Men</p>

                        <h3>15</h3>

                    </div>

                </div>



                <div class="mini-card">

                    <div class="mini-icon customer">
                        🛒
                    </div>

                    <div>

                        <p>Customers</p>

                        <h3>95</h3>

                    </div>

                </div>


            </div>



            <!-- ================= FILTER SECTION ================= -->

            <div class="filter-section">


                <div class="search-box">

                    <span>🔍</span>

                    <input
                        type="text"
                        placeholder="Search users..."
                    >

                </div>


                <select class="role-filter">

                    <option value="all">
                        All Roles
                    </option>

                    <option value="admin">
                        Admin
                    </option>

                    <option value="farmer">
                        Farmer
                    </option>

                    <option value="delivery">
                        Delivery Man
                    </option>

                    <option value="customer">
                        Customer
                    </option>

                </select>


                <select class="status-filter">

                    <option value="all">
                        All Status
                    </option>

                    <option value="active">
                        Active
                    </option>

                    <option value="inactive">
                        Inactive
                    </option>

                </select>


            </div>



            <!-- ================= USERS TABLE ================= -->

            <div class="users-card">


                <div class="table-header">

                    <div>

                        <h3>User List</h3>

                        <p>151 users found</p>

                    </div>

                </div>



                <div class="table-container">


                    <table>


                        <thead>

                            <tr>

                                <th>User</th>

                                <th>Email</th>

                                <th>Phone</th>

                                <th>Role</th>

                                <th>Status</th>

                                <th>Joined</th>

                                <th>Action</th>

                            </tr>

                        </thead>



                        <tbody>


                            <!-- ADMIN -->

                            <tr>

                                <td>

                                    <div class="user-info">

                                        <div class="user-avatar admin-avatar">
                                            A
                                        </div>

                                        <div>

                                            <strong>Admin</strong>

                                            <span>ID: #USR001</span>

                                        </div>

                                    </div>

                                </td>


                                <td>
                                    admin@nobanno.com
                                </td>


                                <td>
                                    01700000000
                                </td>


                                <td>

                                    <span class="role admin-role">
                                        Admin
                                    </span>

                                </td>


                                <td>

                                    <span class="status active">
                                        Active
                                    </span>

                                </td>


                                <td>
                                    01 Jan 2026
                                </td>


                                <td>

                                    <button class="action-btn view">
                                        View
                                    </button>

                                    <button class="action-btn edit">
                                        Edit
                                    </button>

                                </td>

                            </tr>



                            <!-- FARMER -->

                            <tr>

                                <td>

                                    <div class="user-info">

                                        <div class="user-avatar farmer-avatar">
                                            R
                                        </div>

                                        <div>

                                            <strong>Rahim Ahmed</strong>

                                            <span>ID: #USR002</span>

                                        </div>

                                    </div>

                                </td>


                                <td>
                                    rahim@gmail.com
                                </td>


                                <td>
                                    01711111111
                                </td>


                                <td>

                                    <span class="role farmer-role">
                                        Farmer
                                    </span>

                                </td>


                                <td>

                                    <span class="status active">
                                        Active
                                    </span>

                                </td>


                                <td>
                                    12 Mar 2026
                                </td>


                                <td>

                                    <button class="action-btn view">
                                        View
                                    </button>

                                    <button class="action-btn edit">
                                        Edit
                                    </button>

                                </td>

                            </tr>



                            <!-- DELIVERY MAN -->

                            <tr>

                                <td>

                                    <div class="user-info">

                                        <div class="user-avatar delivery-avatar">
                                            S
                                        </div>

                                        <div>

                                            <strong>Shakil Islam</strong>

                                            <span>ID: #USR003</span>

                                        </div>

                                    </div>

                                </td>


                                <td>
                                    shakil@gmail.com
                                </td>


                                <td>
                                    01722222222
                                </td>


                                <td>

                                    <span class="role delivery-role">
                                        Delivery Man
                                    </span>

                                </td>


                                <td>

                                    <span class="status active">
                                        Active
                                    </span>

                                </td>


                                <td>
                                    20 Apr 2026
                                </td>


                                <td>

                                    <button class="action-btn view">
                                        View
                                    </button>

                                    <button class="action-btn edit">
                                        Edit
                                    </button>

                                </td>

                            </tr>



                            <!-- CUSTOMER -->

                            <tr>

                                <td>

                                    <div class="user-info">

                                        <div class="user-avatar customer-avatar">
                                            J
                                        </div>

                                        <div>

                                            <strong>Jannat Akter</strong>

                                            <span>ID: #USR004</span>

                                        </div>

                                    </div>

                                </td>


                                <td>
                                    jannat@gmail.com
                                </td>


                                <td>
                                    01733333333
                                </td>


                                <td>

                                    <span class="role customer-role">
                                        Customer
                                    </span>

                                </td>


                                <td>

                                    <span class="status active">
                                        Active
                                    </span>

                                </td>


                                <td>
                                    05 May 2026
                                </td>


                                <td>

                                    <button class="action-btn view">
                                        View
                                    </button>

                                    <button class="action-btn edit">
                                        Edit
                                    </button>

                                </td>

                            </tr>



                            <!-- CUSTOMER -->

                            <tr>

                                <td>

                                    <div class="user-info">

                                        <div class="user-avatar customer-avatar">
                                            K
                                        </div>

                                        <div>

                                            <strong>Karim Hasan</strong>

                                            <span>ID: #USR005</span>

                                        </div>

                                    </div>

                                </td>


                                <td>
                                    karim@gmail.com
                                </td>


                                <td>
                                    01744444444
                                </td>


                                <td>

                                    <span class="role customer-role">
                                        Customer
                                    </span>

                                </td>


                                <td>

                                    <span class="status inactive">
                                        Inactive
                                    </span>

                                </td>


                                <td>
                                    15 May 2026
                                </td>


                                <td>

                                    <button class="action-btn view">
                                        View
                                    </button>

                                    <button class="action-btn edit">
                                        Edit
                                    </button>

                                </td>

                            </tr>


                        </tbody>


                    </table>

                </div>



                <!-- PAGINATION -->

                <div class="pagination">

                    <button class="page-btn">
                        ‹
                    </button>

                    <button class="page-btn current">
                        1
                    </button>

                    <button class="page-btn">
                        2
                    </button>

                    <button class="page-btn">
                        3
                    </button>

                    <span>...</span>

                    <button class="page-btn">
                        16
                    </button>

                    <button class="page-btn">
                        ›
                    </button>

                </div>


            </div>


        </section>


    </main>


</body>

</html>