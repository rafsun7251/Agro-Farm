<?php

require_once __DIR__ . '/../admin_auth.php';
require_once __DIR__ . '/../db.php';


// ==========================================
// CHECK CROP ID
// ==========================================

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {

    die("Invalid crop ID.");

}

$crop_id = (int) $_GET['id'];


// ==========================================
// FETCH CROP
// ==========================================

$query = "
    SELECT
        crop_id,
        crop_name,
        category,
        description,
        price_per_kg,
        quantity,
        unit,
        status
    FROM crops
    WHERE crop_id = ?
";


$stmt = mysqli_prepare($conn, $query);

mysqli_stmt_bind_param(
    $stmt,
    "i",
    $crop_id
);

mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);


if (mysqli_num_rows($result) == 0) {

    die("Crop not found.");

}


$crop = mysqli_fetch_assoc($result);


// ==========================================
// UPDATE CROP
// ==========================================

$errorMessage = "";

$successMessage = "";


if ($_SERVER["REQUEST_METHOD"] === "POST") {


    // Get form values

    $crop_name =
        trim($_POST['crop_name']);

    $category =
        $_POST['category'];

    $description =
        trim($_POST['description']);

    $price_per_kg =
        $_POST['price_per_kg'];

    $quantity =
        $_POST['quantity'];

    $unit =
        trim($_POST['unit']);

    $status =
        $_POST['status'];


    // ==========================================
    // VALIDATION
    // ==========================================

    if (
        empty($crop_name) ||
        empty($category) ||
        empty($price_per_kg) ||
        empty($quantity) ||
        empty($unit) ||
        empty($status)
    ) {

        $errorMessage =
            "Please fill in all required fields.";

    }

    elseif (
        !is_numeric($price_per_kg) ||
        $price_per_kg < 0
    ) {

        $errorMessage =
            "Please enter a valid price.";

    }

    elseif (
        !is_numeric($quantity) ||
        $quantity < 0
    ) {

        $errorMessage =
            "Please enter a valid quantity.";

    }

    else {


        // ==========================================
        // UPDATE DATABASE
        // ==========================================

        $updateQuery = "
            UPDATE crops

            SET
                crop_name = ?,
                category = ?,
                description = ?,
                price_per_kg = ?,
                quantity = ?,
                unit = ?,
                status = ?

            WHERE crop_id = ?
        ";


        $updateStmt =
            mysqli_prepare(
                $conn,
                $updateQuery
            );


        mysqli_stmt_bind_param(
            $updateStmt,
            "sssddssi",
            $crop_name,
            $category,
            $description,
            $price_per_kg,
            $quantity,
            $unit,
            $status,
            $crop_id
        );


        if (
            mysqli_stmt_execute(
                $updateStmt
            )
        ) {

            header(
                "Location: CropManagement.php?updated=1"
            );

            exit();

        }

        else {

            $errorMessage =
                "Failed to update crop: "
                . mysqli_error($conn);

        }

    }

}

?>

<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Agro-Farm | Edit Crop
    </title>

    <link
        rel="stylesheet"
        href="../css/EditCrop.css"
    >

</head>


<body>


<div class="page-container">


    <!-- ==========================================
         HEADER
    =========================================== -->

    <div class="page-header">

        <div>

            <h1>
                Edit Crop
            </h1>

            <p>
                Update crop information
            </p>

        </div>


        <a
            href="CropManagement.php"
            class="back-btn"
        >

            ← Back to Crops

        </a>

    </div>



    <!-- ==========================================
         FORM CARD
    =========================================== -->

    <div class="form-card">


        <?php if (!empty($errorMessage)) { ?>

            <div class="error-message">

                <?php
                echo htmlspecialchars(
                    $errorMessage
                );
                ?>

            </div>

        <?php } ?>



        <form
            method="POST"
            action=""
        >


            <!-- ==================================
                 CROP NAME
            =================================== -->

            <div class="form-group">

                <label for="crop_name">

                    Crop Name
                    <span>*</span>

                </label>

                <input
                    type="text"
                    id="crop_name"
                    name="crop_name"
                    value="<?php
                    echo htmlspecialchars(
                        $crop['crop_name']
                    );
                    ?>"
                    required
                >

            </div>



            <!-- ==================================
                 CATEGORY
            =================================== -->

            <div class="form-group">

                <label for="category">

                    Category
                    <span>*</span>

                </label>

                <select
                    id="category"
                    name="category"
                    required
                >

                    <option
                        value="vegetables"
                        <?php
                        if (
                            $crop['category']
                            === 'vegetables'
                        ) {
                            echo 'selected';
                        }
                        ?>
                    >
                        Vegetables
                    </option>


                    <option
                        value="grains"
                        <?php
                        if (
                            $crop['category']
                            === 'grains'
                        ) {
                            echo 'selected';
                        }
                        ?>
                    >
                        Grains
                    </option>


                    <option
                        value="fruits"
                        <?php
                        if (
                            $crop['category']
                            === 'fruits'
                        ) {
                            echo 'selected';
                        }
                        ?>
                    >
                        Fruits
                    </option>


                    <option
                        value="other"
                        <?php
                        if (
                            $crop['category']
                            === 'other'
                        ) {
                            echo 'selected';
                        }
                        ?>
                    >
                        Other
                    </option>

                </select>

            </div>



            <!-- ==================================
                 DESCRIPTION
            =================================== -->

            <div class="form-group">

                <label for="description">

                    Description

                </label>

                <textarea
                    id="description"
                    name="description"
                    rows="4"
                ><?php

                    echo htmlspecialchars(
                        $crop['description']
                    );

                ?></textarea>

            </div>



            <!-- ==================================
                 PRICE + QUANTITY
            =================================== -->

            <div class="form-row">


                <div class="form-group">

                    <label for="price_per_kg">

                        Price per Kg
                        <span>*</span>

                    </label>

                    <input
                        type="number"
                        id="price_per_kg"
                        name="price_per_kg"
                        step="0.01"
                        min="0"
                        value="<?php
                        echo htmlspecialchars(
                            $crop['price_per_kg']
                        );
                        ?>"
                        required
                    >

                </div>



                <div class="form-group">

                    <label for="quantity">

                        Quantity
                        <span>*</span>

                    </label>

                    <input
                        type="number"
                        id="quantity"
                        name="quantity"
                        step="0.01"
                        min="0"
                        value="<?php
                        echo htmlspecialchars(
                            $crop['quantity']
                        );
                        ?>"
                        required
                    >

                </div>


            </div>



            <!-- ==================================
                 UNIT + STATUS
            =================================== -->

            <div class="form-row">


                <div class="form-group">

                    <label for="unit">

                        Unit
                        <span>*</span>

                    </label>

                    <input
                        type="text"
                        id="unit"
                        name="unit"
                        value="<?php
                        echo htmlspecialchars(
                            $crop['unit']
                        );
                        ?>"
                        required
                    >

                </div>



                <div class="form-group">

                    <label for="status">

                        Status
                        <span>*</span>

                    </label>

                    <select
                        id="status"
                        name="status"
                        required
                    >

                        <option
                            value="available"
                            <?php
                            if (
                                $crop['status']
                                === 'available'
                            ) {
                                echo 'selected';
                            }
                            ?>
                        >
                            Available
                        </option>


                        <option
                            value="out_of_stock"
                            <?php
                            if (
                                $crop['status']
                                === 'out_of_stock'
                            ) {
                                echo 'selected';
                            }
                            ?>
                        >
                            Out of Stock
                        </option>


                        <option
                            value="inactive"
                            <?php
                            if (
                                $crop['status']
                                === 'inactive'
                            ) {
                                echo 'selected';
                            }
                            ?>
                        >
                            Inactive
                        </option>

                    </select>

                </div>


            </div>



            <!-- ==================================
                 BUTTONS
            =================================== -->

            <div class="form-actions">


                <a
                    href="CropManagement.php"
                    class="cancel-btn"
                >

                    Cancel

                </a>


                <button
                    type="submit"
                    class="save-btn"
                >

                    Update Crop

                </button>


            </div>


        </form>


    </div>


</div>


</body>

</html>