<?php

session_start();

require_once __DIR__ . '/../db.php';

$errorMessage = "";
$successMessage = "";

if (isset($_SESSION['user_id'])) {

    if (
        isset($_SESSION['role']) &&
        $_SESSION['role'] === 'admin'
    ) {
        header("Location: AdminDashboard.php");
        exit();
    }
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $firstName = trim($_POST['first_name'] ?? '');
    $lastName = trim($_POST['last_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';
    $phone = trim($_POST['phone'] ?? '');

    if (
        $firstName === '' ||
        $lastName === '' ||
        $email === '' ||
        $password === '' ||
        $confirmPassword === ''
    ) {

        $errorMessage = "Please fill in all required fields.";

    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {

        $errorMessage = "Please enter a valid email address.";

    } elseif (strlen($password) < 6) {

        $errorMessage = "Password must be at least 6 characters.";

    } elseif ($password !== $confirmPassword) {

        $errorMessage = "Passwords do not match.";

    } else {

        $checkQuery = "
            SELECT user_id
            FROM users
            WHERE email = ?
            LIMIT 1
        ";

        $checkStmt = mysqli_prepare($conn, $checkQuery);

        mysqli_stmt_bind_param(
            $checkStmt,
            "s",
            $email
        );

        mysqli_stmt_execute($checkStmt);

        $checkResult = mysqli_stmt_get_result($checkStmt);

        if (mysqli_num_rows($checkResult) > 0) {

            $errorMessage =
                "An account with this email already exists.";

        } else {

            $hashedPassword = password_hash(
                $password,
                PASSWORD_DEFAULT
            );

            $insertQuery = "
                INSERT INTO users
                (
                    first_name,
                    last_name,
                    email,
                    password,
                    role,
                    phone
                )
                VALUES
                (?, ?, ?, ?, 'customer', ?)
            ";

            $insertStmt = mysqli_prepare(
                $conn,
                $insertQuery
            );

            mysqli_stmt_bind_param(
                $insertStmt,
                "sssss",
                $firstName,
                $lastName,
                $email,
                $hashedPassword,
                $phone
            );

           if (mysqli_stmt_execute($insertStmt)) {

    /*
     * Get the newly created user's ID.
     */
    $newUserId = mysqli_insert_id($conn);


    /*
     * Create the corresponding customer record.
     */
    $customerQuery = "
        INSERT INTO customers
        (
            user_id
        )
        VALUES
        (?)
    ";

    $customerStmt = mysqli_prepare(
        $conn,
        $customerQuery
    );


    if ($customerStmt) {

        mysqli_stmt_bind_param(
            $customerStmt,
            "i",
            $newUserId
        );


        if (mysqli_stmt_execute($customerStmt)) {

            $successMessage =
                "Account created successfully. You can now login.";

            $firstName = "";
            $lastName = "";
            $email = "";
            $phone = "";

        } else {

            /*
             * Customer record could not be created.
             * Remove the user record so we don't leave
             * an incomplete account.
             */

            $deleteQuery = "
                DELETE FROM users
                WHERE user_id = ?
            ";

            $deleteStmt = mysqli_prepare(
                $conn,
                $deleteQuery
            );

            if ($deleteStmt) {

                mysqli_stmt_bind_param(
                    $deleteStmt,
                    "i",
                    $newUserId
                );

                mysqli_stmt_execute(
                    $deleteStmt
                );

                mysqli_stmt_close(
                    $deleteStmt
                );
            }

            $errorMessage =
                "Unable to create customer profile. Please try again.";
        }


        mysqli_stmt_close(
            $customerStmt
        );

    } else {

        $errorMessage =
            "Unable to create customer profile. Please try again.";
    }


} else {

    $errorMessage =
        "Unable to create account. Please try again.";
}

            mysqli_stmt_close($insertStmt);
        }

        mysqli_stmt_close($checkStmt);
    }
}

?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title> নবান্ন | Create Account</title>

    <link
        rel="stylesheet"
        href="../css/register.css"
    >

</head>

<body>

<div class="register-page">

    <div class="register-left">

        <div class="brand">

            <div class="brand-icon">
                🌾
            </div>

            <div>
                <h1>নবান্ন</h1>
                <p>Fresh From Farmers</p>
            </div>

        </div>

        <div class="welcome-content">

            <h2>Join নবান্ন</h2>

            <p>
                Create your account and connect
                with a growing agricultural marketplace.
            </p>

            <div class="feature-list">

                <div class="feature">
                    <span>✓</span>
                    <p>Buy fresh agricultural products</p>
                </div>

                <div class="feature">
                    <span>✓</span>
                    <p>Discover products from farmers</p>
                </div>

                <div class="feature">
                    <span>✓</span>
                    <p>Track your orders easily</p>
                </div>

            </div>

        </div>

    </div>


    <div class="register-right">

        <div class="register-card">

            <div class="register-header">

                <div class="mobile-logo">
                    🌾
                </div>

                <h2>Create Account</h2>

                <p>Register as a customer</p>

            </div>


            <?php if ($errorMessage !== ""): ?>

                <div class="error-message">

                    <span>!</span>

                    <?php
                    echo htmlspecialchars($errorMessage);
                    ?>

                </div>

            <?php endif; ?>


            <?php if ($successMessage !== ""): ?>

                <div class="success-message">

                    <span>✓</span>

                    <?php
                    echo htmlspecialchars($successMessage);
                    ?>

                </div>

            <?php endif; ?>


            <form
                method="POST"
                action=""
            >

                <div class="form-row">

                    <div class="form-group">

                        <label for="first_name">
                            First Name
                        </label>

                        <input
                            type="text"
                            id="first_name"
                            name="first_name"
                            placeholder="First name"
                            value="<?php
                            echo htmlspecialchars(
                                $firstName ?? ''
                            );
                            ?>"
                            required
                        >

                    </div>


                    <div class="form-group">

                        <label for="last_name">
                            Last Name
                        </label>

                        <input
                            type="text"
                            id="last_name"
                            name="last_name"
                            placeholder="Last name"
                            value="<?php
                            echo htmlspecialchars(
                                $lastName ?? ''
                            );
                            ?>"
                            required
                        >

                    </div>

                </div>


                <div class="form-group">

                    <label for="email">
                        Email Address
                    </label>

                    <input
                        type="email"
                        id="email"
                        name="email"
                        placeholder="Enter your email"
                        value="<?php
                        echo htmlspecialchars(
                            $email ?? ''
                        );
                        ?>"
                        required
                    >

                </div>


                <div class="form-group">

                    <label for="phone">
                        Phone Number
                    </label>

                    <input
                        type="tel"
                        id="phone"
                        name="phone"
                        placeholder="Enter your phone number"
                        value="<?php
                        echo htmlspecialchars(
                            $phone ?? ''
                        );
                        ?>"
                    >

                </div>


                <div class="form-group">

                    <label for="password">
                        Password
                    </label>

                    <input
                        type="password"
                        id="password"
                        name="password"
                        placeholder="Minimum 6 characters"
                        required
                    >

                </div>


                <div class="form-group">

                    <label for="confirm_password">
                        Confirm Password
                    </label>

                    <input
                        type="password"
                        id="confirm_password"
                        name="confirm_password"
                        placeholder="Re-enter your password"
                        required
                    >

                </div>


                <button
                    type="submit"
                    class="register-btn"
                >
                    Create Account
                </button>

            </form>


            <div class="login-link">

                Already have an account?

                <a href="login.php">
                    Login
                </a>

            </div>


            <div class="register-footer">

                <p>
                    © <?php echo date("Y"); ?>
                    Agro-Farm. All rights reserved.
                </p>

            </div>

        </div>

    </div>

</div>

</body>

</html>